import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/materia.dart';
import '../models/horario.dart';
import '../models/clase.dart';
import '../services/db_service.dart';
import 'grabacion_screen.dart';
import 'horario_screen.dart';
import 'apuntes/apuntes_screen.dart';
import 'ajustes_screen.dart';

/// Pantalla raíz con navegación inferior.
class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _indice = 0;

  final _pantallas = const [
    HomeScreen(),
    ApuntesScreen(),
    HorarioScreen(),
    AjustesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pantallas[_indice]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _indice,
        onDestinationSelected: (i) => setState(() => _indice = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Inicio'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'Apuntes'),
          NavigationDestination(icon: Icon(Icons.calendar_today_outlined), label: 'Horario'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Ajustes'),
        ],
      ),
    );
  }
}

// ───────────────────────────── HomeScreen ──────────────────────────────────

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Materia> _materias = [];
  List<BloqueHorario> _bloques = [];
  List<Clase> _clases = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _cargar();
  }

  Future<void> _cargar() async {
    final db = DBService.instancia;
    final materias = await db.listarMaterias();
    final bloques = await db.listarBloques();
    final clases = await db.listarClases();
    if (mounted) {
      setState(() {
        _materias = materias;
        _bloques = bloques;
        _clases = clases;
        _cargando = false;
      });
    }
  }

  /// Devuelve el próximo bloque de hoy o nulo.
  ({BloqueHorario bloque, Materia? materia, int minutosFaltantes})? _proximaClaseHoy() {
    final ahora = DateTime.now();
    final diaActual = ahora.weekday; // 1=lunes … 7=domingo
    final minutosActuales = ahora.hour * 60 + ahora.minute;

    final bloquesHoy = _bloques
        .where((b) => b.diaSemana == diaActual && b.horaInicio > minutosActuales)
        .toList()
      ..sort((a, b) => a.horaInicio.compareTo(b.horaInicio));

    if (bloquesHoy.isEmpty) return null;
    final b = bloquesHoy.first;
    Materia? mat;
    for (final m in _materias) {
      if (m.id == b.materiaId) { mat = m; break; }
    }
    return (bloque: b, materia: mat, minutosFaltantes: b.horaInicio - minutosActuales);
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) {
      return const Center(child: CircularProgressIndicator());
    }

    final proxima = _proximaClaseHoy();
    final clasesRecientes = _clases.take(5).toList();

    return RefreshIndicator(
      onRefresh: _cargar,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
        children: [
          // ── Encabezado ──
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hola 👋',
                      style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 2),
                  Text(_fechaDeHoy(),
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
              Container(
                width: 36,
                height: 36,
                decoration: const BoxDecoration(
                  color: AppColors.superficie,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.notifications_outlined,
                    color: AppColors.texto, size: 18),
              ),
            ],
          ),
          const SizedBox(height: 18),

          // ── Próxima clase ──
          if (proxima != null)
            _TarjetaProximaClase(
              materia: proxima.materia?.nombre ?? 'Clase',
              minutosFaltantes: proxima.minutosFaltantes,
              materias: _materias,
              onGrabar: _cargar,
            )
          else if (_materias.isNotEmpty)
            _TarjetaGrabarLibre(materias: _materias, onGrabar: _cargar)
          else
            _TarjetaSinMaterias(),

          const SizedBox(height: 20),

          // ── Clases recientes ──
          Text('Clases recientes',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),

          if (clasesRecientes.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text('Graba tu primera clase para verla aquí',
                  style: Theme.of(context).textTheme.bodySmall),
            )
          else
            ...clasesRecientes.map((c) {
              Materia? mat;
              for (final m in _materias) {
                if (m.id == c.materiaId) { mat = m; break; }
              }
              return _TarjetaClaseReciente(clase: c, materia: mat);
            }),
        ],
      ),
    );
  }

  String _fechaDeHoy() {
    const dias = [
      'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'
    ];
    const meses = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio',
      'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    final ahora = DateTime.now();
    final dia = dias[ahora.weekday - 1];
    final mes = meses[ahora.month - 1];
    return '${dia[0].toUpperCase()}${dia.substring(1)}, ${ahora.day} de $mes';
  }
}

// ── Tarjeta: próxima clase del día ──────────────────────────────────────────

class _TarjetaProximaClase extends StatelessWidget {
  final String materia;
  final int minutosFaltantes;
  final List<Materia> materias;
  final VoidCallback onGrabar;

  const _TarjetaProximaClase({
    required this.materia,
    required this.minutosFaltantes,
    required this.materias,
    required this.onGrabar,
  });

  @override
  Widget build(BuildContext context) {
    final label = minutosFaltantes < 60
        ? 'PRÓXIMA CLASE EN $minutosFaltantes MIN'
        : 'PRÓXIMA CLASE HOY';
    return _TarjetaGrabacion(
      label: label,
      titulo: materia,
      materias: materias,
      onGrabar: onGrabar,
    );
  }
}

// ── Tarjeta: sin próxima pero con materias ──────────────────────────────────

class _TarjetaGrabarLibre extends StatelessWidget {
  final List<Materia> materias;
  final VoidCallback onGrabar;
  const _TarjetaGrabarLibre({required this.materias, required this.onGrabar});

  @override
  Widget build(BuildContext context) {
    return _TarjetaGrabacion(
      label: 'SIN CLASES PROGRAMADAS HOY',
      titulo: 'Grabar de todas formas',
      materias: materias,
      onGrabar: onGrabar,
    );
  }
}

// ── Tarjeta base de grabación ────────────────────────────────────────────────

class _TarjetaGrabacion extends StatelessWidget {
  final String label;
  final String titulo;
  final List<Materia> materias;
  final VoidCallback onGrabar;

  const _TarjetaGrabacion({
    required this.label,
    required this.titulo,
    required this.materias,
    required this.onGrabar,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.superficie,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borde),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textoSecundario,
              fontSize: 11,
              letterSpacing: 0.6,
            ),
          ),
          const SizedBox(height: 4),
          Text(titulo, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 14),
          InkWell(
            borderRadius: BorderRadius.circular(30),
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => GrabacionScreen(materias: materias),
                ),
              );
              onGrabar();
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(
                    color: AppColors.grabando,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.mic, color: AppColors.fondo, size: 20),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Grabar ahora',
                  style: TextStyle(
                    color: AppColors.grabando,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Sin materias aún ─────────────────────────────────────────────────────────

class _TarjetaSinMaterias extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.superficie,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borde),
      ),
      child: Column(
        children: [
          const Icon(Icons.calendar_today_outlined,
              color: AppColors.textoTerciario, size: 32),
          const SizedBox(height: 8),
          Text('Crea materias en Horario para empezar',
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ── Tarjeta clase reciente ───────────────────────────────────────────────────

class _TarjetaClaseReciente extends StatelessWidget {
  final Clase clase;
  final Materia? materia;

  const _TarjetaClaseReciente({required this.clase, this.materia});

  @override
  Widget build(BuildContext context) {
    final estado = switch (clase.estado) {
      EstadoClase.grabando => 'Grabando...',
      EstadoClase.grabada => 'Audio guardado',
      EstadoClase.sincronizando => 'Sincronizando...',
      EstadoClase.transcribiendo => 'Transcribiendo...',
      EstadoClase.lista => 'Guía lista',
      EstadoClase.error => 'Error al procesar',
    };
    final icono = clase.estado == EstadoClase.lista
        ? Icons.check
        : Icons.access_time;
    final colorIcono = clase.estado == EstadoClase.lista
        ? AppColors.secundario
        : AppColors.primario;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.superficieAlt,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: colorIcono.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icono, color: colorIcono, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(materia?.nombre ?? 'Sin materia',
                    style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 2),
                Text(estado,
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          const Icon(Icons.chevron_right,
              color: AppColors.textoTerciario, size: 18),
        ],
      ),
    );
  }
}
