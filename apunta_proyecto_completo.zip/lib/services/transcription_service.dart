import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;

enum ProveedorTranscripcion { openai, groq, gemini }

/// Transcribe audio usando OpenAI Whisper, Groq Whisper o Google Gemini.
/// Gemini no requiere VPN y tiene capa gratuita generosa — ideal para Venezuela.
class TranscriptionService {
  TranscriptionService._();
  static final TranscriptionService instancia = TranscriptionService._();

  static const _urlOpenAI = 'https://api.openai.com/v1/audio/transcriptions';
  static const _urlGroq   = 'https://api.groq.com/openai/v1/audio/transcriptions';

  String? _apiKey;
  ProveedorTranscripcion _proveedor = ProveedorTranscripcion.gemini;

  void configurar({
    required String apiKey,
    ProveedorTranscripcion proveedor = ProveedorTranscripcion.gemini,
  }) {
    _apiKey = apiKey;
    _proveedor = proveedor;
  }

  bool get estaConfigurado => _apiKey != null && _apiKey!.isNotEmpty;
  ProveedorTranscripcion get proveedor => _proveedor;

  Future<String> transcribir(String ruta) async {
    if (!estaConfigurado) {
      throw TranscriptionException(
          'API key no configurada. Ve a Ajustes para agregarla.');
    }

    final archivo = File(ruta);
    if (!await archivo.exists()) {
      throw TranscriptionException('Archivo de audio no encontrado: $ruta');
    }

    if (_proveedor == ProveedorTranscripcion.gemini) {
      return _transcribirConGemini(archivo, ruta);
    }

    return _transcribirConWhisper(archivo, ruta);
  }

  /// Transcripción con Gemini 1.5 Flash — audio como base64 inline.
  /// No requiere VPN, funciona directo desde Venezuela.
  Future<String> _transcribirConGemini(File archivo, String ruta) async {
    final bytes = await archivo.readAsBytes();
    final base64Audio = base64Encode(bytes);

    // Detectar MIME type por extensión
    final ext = ruta.toLowerCase().split('.').last;
    final mimeType = ext == 'm4a' ? 'audio/mp4'
        : ext == 'aac'           ? 'audio/aac'
        : ext == 'mp3'           ? 'audio/mpeg'
        : ext == 'wav'           ? 'audio/wav'
        : ext == 'ogg'           ? 'audio/ogg'
        :                          'audio/mp4'; // fallback para m4a

    final url = 'https://generativelanguage.googleapis.com/v1beta/models/'
        'gemini-2.0-flash:generateContent?key=$_apiKey';

    final body = jsonEncode({
      'contents': [
        {
          'parts': [
            {
              'inline_data': {
                'mime_type': mimeType,
                'data': base64Audio,
              }
            },
            {
              'text': 'Transcribe este audio de una clase universitaria en español. '
                  'Devuelve SOLO el texto hablado, sin comentarios ni explicaciones. '
                  'Mantén la puntuación correcta y separa los párrafos cuando cambié el tema.'
            }
          ]
        }
      ],
      'generationConfig': {
        'temperature': 0.1,
        'maxOutputTokens': 8192,
      }
    });

    final respuesta = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: body,
    ).timeout(
      const Duration(seconds: 120),
      onTimeout: () => throw TranscriptionException(
          'Tiempo de espera agotado. El audio puede ser muy largo o hay problemas de red.'),
    );

    if (respuesta.statusCode != 200) {
      final error = jsonDecode(respuesta.body);
      final msg = error['error']?['message'] ?? respuesta.body;
      throw TranscriptionException(
          'Error de transcripción Gemini (${respuesta.statusCode}): $msg');
    }

    final json = jsonDecode(respuesta.body);
    final texto = json['candidates']?[0]?['content']?['parts']?[0]?['text'];
    if (texto == null || (texto as String).trim().isEmpty) {
      throw TranscriptionException('Gemini no devolvió texto de transcripción.');
    }
    return texto.trim();
  }

  /// Transcripción con Whisper (OpenAI o Groq) — multipart upload.
  Future<String> _transcribirConWhisper(File archivo, String ruta) async {
    final url = _proveedor == ProveedorTranscripcion.groq
        ? _urlGroq
        : _urlOpenAI;

    final modelo = _proveedor == ProveedorTranscripcion.groq
        ? 'whisper-large-v3-turbo'
        : 'whisper-1';

    final request = http.MultipartRequest('POST', Uri.parse(url));
    request.headers['Authorization'] = 'Bearer $_apiKey';
    request.fields['model'] = modelo;
    request.fields['language'] = 'es';
    request.fields['response_format'] = 'verbose_json';
    request.files.add(await http.MultipartFile.fromPath('file', ruta));

    final streamed = await request.send();
    final respuesta = await http.Response.fromStream(streamed);

    if (respuesta.statusCode != 200) {
      final error = jsonDecode(respuesta.body);
      throw TranscriptionException(
          'Error de transcripción (${respuesta.statusCode}): '
          '${error['error']?['message'] ?? respuesta.body}');
    }

    final json = jsonDecode(respuesta.body);
    if (json['segments'] != null) {
      return (json['segments'] as List)
          .map((s) => s['text'] as String)
          .join(' ')
          .trim();
    }
    return json['text'] as String? ?? '';
  }
}

class TranscriptionException implements Exception {
  final String mensaje;
  const TranscriptionException(this.mensaje);

  @override
  String toString() => 'TranscriptionException: $mensaje';
}
