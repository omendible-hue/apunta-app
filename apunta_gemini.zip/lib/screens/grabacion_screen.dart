import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import '../theme/app_theme.dart';
import '../models/materia.dart';
import '../models/clase.dart';
import '../services/db_service.dart';
import '../services/recording_service.dart';

const _uuid = Uuid();

/// Pantalla de grabación de una clase.
/// Permite seleccionar la materia, iniciar/detener la grabación y
/// guarda automáticamente el registro en la base de datos local al terminar.
class GrabacionScreen extends StatefulWidget {
  final List<Materia> materias;

  const GrabacionScreen({super.key, required this.materias});

  @override
  State<GrabacionScreen> createState() => _GrabacionScreenState();
}

class _GrabacionScreenState extends State<GrabacionScreen> {
  bool _grabando = false;
  DateTime? _inicio;
  String? _materiaSeleccionadaId;
  String _mensaje = '';
  bool _guardando = false;

  @override
  void initState() {
    super.initState();
    if (widget.materias.isNotEmpty) {
      _materiaSeleccionadaId = widget.materias.first.id;
    }
  }

  Materia? get _materiaActual {
    if (_materiaSeleccionadaId == null) return null;
    for (final m in widget.materias) {
      if (m.id == _materiaSeleccionadaId) return m;
    }
    return null;
  }

  Future<void> _alternarGrabacion() async {
    if (_grabando) {
      // ── Detener ──
      setState(() => _guardando = true);
      await RecordingService.detener();

      final duracion = _inicio != null
          ? DateTime.now().difference(_inicio!).inSeconds
          : null;

      // Buscar el archivo de audio generado.
      // El servicio Kotlin guarda en filesDir/grabaciones, que en Flutter
      // corresponde a getApplicationSupportDirectory() (NO Documents).
      final dir = await getApplicationSupportDirectory();
      final grabDir = Directory('${dir.path}/grabaciones');
      String? rutaAudio;
      if (await grabDir.exists()) {
        final archivos = grabDir
            .listSync()
            .whereType<File>()
            .where((f) => f.path.endsWith('.m4a') || f.path.endsWith('.aac'))
            .toList()
          ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
        if (archivos.isNotEmpty) {
          rutaAudio = archivos.first.path;
        }
      }

      // Guardar la clase en la base de datos
      if (_materiaSeleccionadaId != null) {
        final clase = Clase(
          id: _uuid.v4(),
          materiaId: _materiaSeleccionadaId!,
          fecha: _inicio ?? DateTime.now(),
          rutaAudio: rutaAudio,
          duracionSegundos: duracion,
          estado: rutaAudio != null ? EstadoClase.grabada : EstadoClase.error,
        );
        await DBService.instancia.guardarClase(clase);
      }

      setState(() {
        _grabando = false;
        _guardando = false;
        _mensaje = rutaAudio != null
            ? '✓ Clase guardada. Puedes verla en Apuntes.'
            : 'Grabación detenida. Verifica los permisos de almacenamiento.';
      });

      // Volver automáticamente tras 2 segundos
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) Navigator.of(context).pop();
    } else {
      // ── Iniciar ──
      if (_materiaSeleccionadaId == null) {
        setState(() => _mensaje = 'Selecciona una materia primero.');
        return;
      }
      final nombre = _materiaActual?.nombre ?? 'Clase';
      final ok = await RecordingService.iniciar(nombre);
      if (!ok) {
        setState(() {
          _mensaje = 'Permiso de micrófono denegado.\n'
              'Ve a Ajustes > Apps > Apunta > Permisos y actívalo.';
        });
        return;
      }
      setState(() {
        _grabando = true;
        _inicio = DateTime.now();
        _mensaje = 'Grabando. Puedes apagar la pantalla — '
            'la grabación continúa en segundo plano.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: AppColors.fondo,
      appBar: AppBar(
        backgroundColor: AppColors.fondo,
        elevation: 0,
        leading: _grabando
            ? const SizedBox()
            : IconButton(
                icon: const Icon(Icons.arrow_back_ios_new, size: 18),
                onPressed: () => Navigator.of(context).pop(),
              ),
        title: Text(
          'Grabar clase',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            children: [
              // ── Selector de materia ──
              if (widget.materias.isEmpty)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.superficie,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    'No tienes materias creadas.\nVe a Horario y crea una primero.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                )
              else if (!_grabando)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.superficie,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.borde),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _materiaSeleccionadaId,
                      isExpanded: true,
                      dropdownColor: AppColors.superficie,
                      style: Theme.of(context).textTheme.bodyMedium,
                      items: widget.materias
                          .map((m) => DropdownMenuItem(
                                value: m.id,
                                child: Row(
                                  children: [
                                    Container(
                                      width: 10,
                                      height: 10,
                                      decoration: BoxDecoration(
                                        color: Color(m.colorHex),
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Text(m.nombre),
                                  ],
                                ),
                              ))
                          .toList(),
                      onChanged: (v) => setState(() => _materiaSeleccionadaId = v),
                    ),
                  ),
                )
              else
                // Mientras graba: muestra nombre de la materia
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppColors.superficie,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (_materiaActual != null)
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: Color(_materiaActual!.colorHex),
                            shape: BoxShape.circle,
                          ),
                        ),
                      const SizedBox(width: 8),
                      Text(
                        _materiaActual?.nombre ?? 'Clase',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ],
                  ),
                ),

              const Spacer(),

              // ── Botón de grabación ──
              if (_guardando)
                Column(
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 16),
                    Text('Guardando...', style: Theme.of(context).textTheme.bodySmall),
                  ],
                )
              else
                GestureDetector(
                  onTap: widget.materias.isEmpty ? null : _alternarGrabacion,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    width: 140,
                    height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _grabando ? cs.error : AppColors.grabando,
                      boxShadow: [
                        BoxShadow(
                          color: (_grabando ? cs.error : AppColors.grabando)
                              .withOpacity(0.4),
                          blurRadius: 30,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                    child: Icon(
                      _grabando ? Icons.stop_rounded : Icons.mic_rounded,
                      color: Colors.white,
                      size: 56,
                    ),
                  ),
                ),

              const SizedBox(height: 24),

              // ── Contador de tiempo ──
              if (_grabando && _inicio != null)
                _ContadorTiempo(inicio: _inicio!),

              const SizedBox(height: 16),

              // ── Mensaje de estado ──
              if (_mensaje.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    _mensaje,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: cs.onSurfaceVariant,
                        ),
                  ),
                ),

              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}

class _ContadorTiempo extends StatefulWidget {
  final DateTime inicio;
  const _ContadorTiempo({required this.inicio});

  @override
  State<_ContadorTiempo> createState() => _ContadorTiempoState();
}

class _ContadorTiempoState extends State<_ContadorTiempo> {
  late Duration _transcurrido;

  @override
  void initState() {
    super.initState();
    _transcurrido = DateTime.now().difference(widget.inicio);
    _tick();
  }

  void _tick() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() =>
          _transcurrido = DateTime.now().difference(widget.inicio));
      _tick();
    });
  }

  @override
  Widget build(BuildContext context) {
    final m = _transcurrido.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = _transcurrido.inSeconds.remainder(60).toString().padLeft(2, '0');
    return Text(
      '$m:$s',
      style: Theme.of(context).textTheme.headlineSmall,
    );
  }
}
