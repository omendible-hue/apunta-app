# 📱 Cómo obtener el APK de Apunta en 15 minutos

## Sin instalar nada en tu PC — GitHub compila todo en la nube 🚀

---

## Paso 1 — Crea una cuenta en GitHub (gratis)

1. Ve a **https://github.com** desde tu PC
2. Haz clic en **"Sign up"** (arriba a la derecha)
3. Escribe tu email, crea una contraseña y un nombre de usuario
4. Confirma el email que te llegue
5. Elige el plan **Free** (el de $0)

---

## Paso 2 — Descarga GitHub Desktop (no necesitas saber comandos)

1. Ve a **https://desktop.github.com**
2. Haz clic en **"Download for Windows"**
3. Instala normalmente (siguiente, siguiente, instalar)
4. Al abrir, haz clic en **"Sign in to GitHub.com"** e inicia sesión

---

## Paso 3 — Sube el código de Apunta a GitHub

1. En GitHub Desktop, haz clic en **"File"** → **"Add Local Repository..."**
   - Si no te aparece esa opción, haz clic en **"Create a Tutorial Repository"** primero para ver el menú
   
2. **Alternativa más fácil:**
   - En GitHub Desktop → **"File"** → **"New Repository..."**
   - Name: `apunta-app`
   - Local path: elige una carpeta vacía en tu escritorio
   - Haz clic en **"Create Repository"**

3. **Copia los archivos:**
   - Extrae el archivo ZIP llamado `apunta_github.zip` en la carpeta que acabas de crear
   - Asegúrate de que los archivos queden DENTRO de la carpeta `apunta-app` (no en una subcarpeta)

4. En GitHub Desktop verás todos los archivos listados en verde
   - En el campo "Summary" escribe: `Apunta app inicial`
   - Haz clic en **"Commit to main"**

5. Haz clic en **"Publish repository"**
   - Deja marcado **"Keep this code private"** si quieres que sea privado
   - Haz clic en **"Publish Repository"**

---

## Paso 4 — GitHub compila el APK automáticamente ☁️

Cuando subas el código, GitHub **automáticamente** inicia la compilación.

1. Ve a **https://github.com** → tu repositorio `apunta-app`
2. Haz clic en la pestaña **"Actions"** (en el menú superior del repo)
3. Verás un proceso llamado **"🎓 Compilar APK Apunta"** ejecutándose
   - Un círculo amarillo = compilando (espera ~5 minutos)
   - Un círculo verde ✅ = ¡listo!
   - Un círculo rojo ❌ = error (escríbele a Claude para ayuda)

4. Haz clic en el proceso completado
5. Baja hasta la sección **"Artifacts"**
6. Haz clic en **"Apunta-APK"** para descargar el APK

---

## Paso 5 — Instala el APK en el teléfono de tu hijo 📲

### En el teléfono Xiaomi/Redmi:

1. **Habilita instalar apps desconocidas:**
   - Ajustes → Aplicaciones → Permisos especiales → Instalar apps desconocidas
   - Activa el permiso para "Chrome" o el explorador de archivos

2. **Transfiere el APK:**
   - Envíatelo por WhatsApp o email al teléfono
   - O conéctalo por USB y cópialo

3. **Instala:**
   - Abre el archivo `.apk` desde el explorador de archivos
   - Toca **"Instalar"**
   - Si aparece advertencia de seguridad → **"Instalar de todas formas"**

4. **Permisos al abrir Apunta:**
   - Micrófono → **Permitir siempre** (necesario para grabar)
   - Notificaciones → **Permitir**
   - Almacenamiento → **Permitir**

5. **Desactiva optimización de batería para Apunta:**
   - Ajustes → Batería → Ahorro de batería → No restringir para Apunta
   - (Crítico en Xiaomi para que la grabación funcione en segundo plano)

---

## Configurar la IA gratuita (Groq)

Para que Apunta genere guías de estudio, necesitas una clave API gratuita:

1. Ve a **https://console.groq.com** → crea cuenta gratuita (con Google)
2. Ve a **API Keys** → **Create API Key** → copia la clave
3. En Apunta → ⚙️ Ajustes → pega la clave en el campo de Groq
4. Guarda los ajustes

¡Listo! Con esto tienes **transcripción + guías de estudio + ejercicios completamente gratis**.

---

## ¿Algo no funcionó?

- **El build falla en Actions:** Revisa el log y envíale una captura a Claude
- **La app se cierra al grabar:** Desactiva "Optimización de batería" en Xiaomi (ver paso 5)
- **No genera la guía:** Verifica que la clave de Groq esté bien copiada en Ajustes

---

*Apunta — Desarrollado con ❤️ para el futuro de tus hijos*
