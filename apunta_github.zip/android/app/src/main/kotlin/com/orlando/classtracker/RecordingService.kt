package com.orlando.classtracker

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Servicio en primer plano (foreground service) que graba audio sin parar
 * aunque la pantalla esté apagada o el teléfono guardado en el bolso.
 *
 * Puntos clave de diseño:
 * - Android EXIGE una notificación visible mientras se graba (no es opcional,
 *   es la única forma legal de que el sistema no mate el proceso). La
 *   diseñamos discreta: ícono fijo, sin sonido, sin vibración.
 * - Usamos MediaRecorder en modo AAC a una tasa de bits moderada para que el
 *   archivo no pese demasiado en una clase de 1-2 horas.
 * - El servicio se declara con foregroundServiceType="microphone" en el
 *   AndroidManifest (obligatorio desde Android 10+).
 */
class RecordingService : Service() {

    private var recorder: MediaRecorder? = null
    private var outputFilePath: String? = null
    private var startTimeMillis: Long = 0L

    companion object {
        const val CHANNEL_ID = "recording_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.orlando.classtracker.START_RECORDING"
        const val ACTION_STOP = "com.orlando.classtracker.STOP_RECORDING"
        const val EXTRA_MATERIA_NOMBRE = "materia_nombre"
        const val EXTRA_OUTPUT_PATH = "output_path"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val materiaNombre = intent.getStringExtra(EXTRA_MATERIA_NOMBRE) ?: "Clase"
                startRecording(materiaNombre)
            }
            ACTION_STOP -> {
                stopRecording()
            }
        }
        // START_STICKY: si el sistema mata el proceso por presión de memoria,
        // intenta recrearlo. La grabación en curso se pierde si eso pasa,
        // pero es la mejor garantía disponible sin root.
        return START_STICKY
    }

    private fun startRecording(materiaNombre: String) {
        createNotificationChannel()

        val dir = File(filesDir, "grabaciones")
        if (!dir.exists()) dir.mkdirs()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "${materiaNombre.replace(" ", "_")}_$timestamp.m4a"
        outputFilePath = File(dir, fileName).absolutePath

        recorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            // 64kbps / 44.1kHz: suficiente para voz clara, tamaño razonable
            // para grabaciones largas (clase de 1.5h ≈ 40-50MB)
            setAudioEncodingBitRate(64000)
            setAudioSamplingRate(44100)
            setOutputFile(outputFilePath)
            prepare()
            start()
        }

        startTimeMillis = System.currentTimeMillis()

        val notification = buildNotification(materiaNombre)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopRecording() {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            // Si la grabación duró menos de 1 segundo, stop() puede lanzar
            // excepción; el archivo igual queda parcialmente guardado.
        }
        recorder = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(materiaNombre: String): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Grabando: $materiaNombre")
            .setContentText("Toca para abrir la app")
            .setSmallIcon(android.R.drawable.presence_audio_online) // reemplazar por ícono propio
            .setOngoing(true)
            .setSilent(true) // sin sonido ni vibración al iniciar
            .setPriority(NotificationCompat.PRIORITY_LOW)
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Grabación de clases",
                NotificationManager.IMPORTANCE_LOW // bajo = sin sonido, discreto
            ).apply {
                description = "Notificación persistente mientras se graba una clase"
                setSound(null, null)
                enableVibration(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
