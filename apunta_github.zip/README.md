# Class Tracker — base del proyecto

Día del padre 2026 🙏🏾 — primer commit del proyecto para tus hijos.

## Qué hay aquí ahora mismo

1. **Modelo de datos** (`lib/models/`): `Materia`, `Clase`, `BloqueHorario`, `Recordatorio`.
   Esto define cómo se relacionan las materias, las clases grabadas, el horario
   recurrente y los recordatorios puntuales (pruebas, entregas).

2. **Servicio de grabación en segundo plano** (lo más riesgoso técnicamente,
   por eso lo hicimos primero):
   - `android/.../RecordingService.kt`: foreground service nativo que graba
     audio con `MediaRecorder`, con notificación silenciosa obligatoria
     (Android no permite grabar audio en background sin ella).
   - `android/.../MainActivity.kt`: el puente (`MethodChannel`) entre Flutter
     y ese servicio nativo.
   - `lib/services/recording_service.dart`: lo que la UI Flutter va a llamar
     (`RecordingService.iniciar(...)` / `RecordingService.detener()`).

## Pasos para probarlo en tu teléfono

```bash
# 1. Instalar Flutter si no lo tienes (https://docs.flutter.dev/get-started/install)
flutter --version

# 2. Dentro de la carpeta del proyecto
cd class_tracker_app
flutter pub get

# 3. Conectar tu Android por USB con depuración activada, y correr:
flutter run
```

## Identidad visual: "Apunta"

Se agregó:
- `lib/theme/app_theme.dart` — paleta completa (`AppColors`) y tipografía
  (Space Grotesk para títulos, Inter para cuerpo, JetBrains Mono para
  duraciones/timestamps).
- `assets/icon/app_icon_source.svg` y `app_icon.png` — el ícono: onda de
  sonido violeta que se transforma en trazo verde-azulado terminado en
  punta de lápiz ámbar. Configurado en `pubspec.yaml` bajo
  `flutter_launcher_icons`.
- `lib/screens/root_screen.dart` — pantalla principal real con navegación
  inferior (Inicio / Apuntes / Horario / Ajustes). Las últimas tres son
  placeholders — se construyen en la siguiente vuelta.
- La pantalla de prueba de grabación se movió a
  `lib/screens/prueba_grabacion_screen.dart` y ahora se abre tocando
  "Grabar ahora" desde la pantalla principal.

### Para generar el ícono real en todos los tamaños de Android

```bash
flutter pub get
dart run flutter_launcher_icons
```

Esto reemplaza automáticamente todos los `ic_launcher.png` en
`android/app/src/main/res/mipmap-*/` con el ícono de Apunta.

### Cómo correr la app completa

```bash
flutter run
```

Verás la pantalla principal con la "próxima clase" y clases recientes de
ejemplo (datos de prueba, todavía no conectados a la base de datos real).
Toca "Grabar ahora" para abrir la pantalla de grabación ya validada.



Agregamos:
- `AndroidManifest.xml` con todos los permisos (micrófono, foreground
  service, notificaciones, cámara, internet, alarmas exactas).
- `android/app/build.gradle`, `android/settings.gradle`,
  `android/gradle.properties` — configuración mínima de compilación
  (`minSdk 26`, Kotlin, Java 17).
- `styles.xml` / `launch_background.xml` — temas mínimos que Flutter exige.
- `lib/main.dart` — pantalla de **un solo botón**: grabar / detener, con
  contador de tiempo. Esta es la prueba de fuego: confirma que el audio se
  graba aunque apagues la pantalla y guardes el teléfono en el bolso.

### Lo único que falta antes de compilar

1. Crear `android/local.properties` apuntando a tu SDK de Flutter:
   ```
   flutter.sdk=/ruta/a/tu/flutter
   ```
   (Esto normalmente lo genera Flutter solo al correr `flutter pub get`,
   pero si no aparece, créalo a mano con esa línea.)
2. Un ícono de la app (`android/app/src/main/res/mipmap-*/ic_launcher.png`).
   Por ahora usará el ícono por defecto de Flutter — el diseño "llamativo
   para jóvenes" lo hacemos en la siguiente vuelta, una vez confirmemos que
   la grabación funciona.

### Cómo correr la prueba

```bash
cd class_tracker_app
flutter pub get
flutter run
```

1. Toca el botón del micrófono — debe pedir permiso y empezar a grabar.
2. Apaga la pantalla del teléfono y guárdalo en el bolsillo o bolso por
   2-3 minutos.
3. Sácalo, ábrelo, toca el botón rojo para detener.
4. Verifica que se generó un archivo `.m4a` en el almacenamiento interno
   de la app (`Android/data/com.orlando.classtracker/files/grabaciones/`
   si usas un explorador de archivos, o revisa el log de Flutter).

**Si esto funciona**, ya validamos lo más riesgoso del proyecto y seguimos
sin miedo con: ícono y diseño visual, organizador de apuntes, horario con
notificaciones, captura de fotos del pizarrón, y el motor de IA
(transcripción + guía de estudio + ejercicios).

**Si el audio se corta o el sistema mata el proceso**, es casi siempre por
optimización de batería agresiva del fabricante (Xiaomi, Samsung, Huawei
suelen ser los peores). La solución es guiar al usuario a desactivar la
optimización de batería para esta app específica — algo que añadiremos
como un paso de onboarding ("autostart" / "sin restricciones").
