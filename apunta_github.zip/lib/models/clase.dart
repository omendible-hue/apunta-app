/// Estado del procesamiento de una clase grabada.
/// El flujo es: grabando -> grabada -> sincronizando -> transcrita -> lista
enum EstadoClase {
  grabando,
  grabada, // audio guardado localmente, pendiente de wifi
  sincronizando,
  transcribiendo,
  lista, // guía de estudio y ejercicios generados
  error,
}

/// Una "clase" es una sesión de grabación: un audio + fotos del pizarrón +
/// (luego) transcripción, guía de estudio y ejercicios.
class Clase {
  final String id;
  final String materiaId;
  final DateTime fecha;
  final String? rutaAudio; // path local del archivo de audio
  final int? duracionSegundos;
  final List<String> rutasFotos; // fotos del pizarrón
  final EstadoClase estado;

  // Resultado del procesamiento con IA (null hasta que estado == lista)
  final String? transcripcion;
  final String? guiaEstudio; // markdown
  final String? ejercicios; // markdown: prácticas + quiz corto

  const Clase({
    required this.id,
    required this.materiaId,
    required this.fecha,
    this.rutaAudio,
    this.duracionSegundos,
    this.rutasFotos = const [],
    this.estado = EstadoClase.grabando,
    this.transcripcion,
    this.guiaEstudio,
    this.ejercicios,
  });

  Clase copyWith({
    String? rutaAudio,
    int? duracionSegundos,
    List<String>? rutasFotos,
    EstadoClase? estado,
    String? transcripcion,
    String? guiaEstudio,
    String? ejercicios,
  }) {
    return Clase(
      id: id,
      materiaId: materiaId,
      fecha: fecha,
      rutaAudio: rutaAudio ?? this.rutaAudio,
      duracionSegundos: duracionSegundos ?? this.duracionSegundos,
      rutasFotos: rutasFotos ?? this.rutasFotos,
      estado: estado ?? this.estado,
      transcripcion: transcripcion ?? this.transcripcion,
      guiaEstudio: guiaEstudio ?? this.guiaEstudio,
      ejercicios: ejercicios ?? this.ejercicios,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'materiaId': materiaId,
        'fecha': fecha.toIso8601String(),
        'rutaAudio': rutaAudio,
        'duracionSegundos': duracionSegundos,
        'rutasFotos': rutasFotos.join('|'), // simple: separadas por '|'
        'estado': estado.name,
        'transcripcion': transcripcion,
        'guiaEstudio': guiaEstudio,
        'ejercicios': ejercicios,
      };

  factory Clase.fromMap(Map<String, dynamic> map) => Clase(
        id: map['id'] as String,
        materiaId: map['materiaId'] as String,
        fecha: DateTime.parse(map['fecha'] as String),
        rutaAudio: map['rutaAudio'] as String?,
        duracionSegundos: map['duracionSegundos'] as int?,
        rutasFotos: (map['rutasFotos'] as String? ?? '')
            .split('|')
            .where((s) => s.isNotEmpty)
            .toList(),
        estado: EstadoClase.values.byName(map['estado'] as String),
        transcripcion: map['transcripcion'] as String?,
        guiaEstudio: map['guiaEstudio'] as String?,
        ejercicios: map['ejercicios'] as String?,
      );
}
