/// Una materia/asignatura (ej. "Matemáticas", "Historia").
/// Cada materia tiene un color asociado para identificarla visualmente
/// en el organizador y el horario.
class Materia {
  final String id;
  final String nombre;
  final int colorHex; // ej. 0xFF7F77DD
  final String? profesor;
  final String? aula;

  const Materia({
    required this.id,
    required this.nombre,
    required this.colorHex,
    this.profesor,
    this.aula,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'nombre': nombre,
        'colorHex': colorHex,
        'profesor': profesor,
        'aula': aula,
      };

  factory Materia.fromMap(Map<String, dynamic> map) => Materia(
        id: map['id'] as String,
        nombre: map['nombre'] as String,
        colorHex: map['colorHex'] as int,
        profesor: map['profesor'] as String?,
        aula: map['aula'] as String?,
      );
}
