/// Un bloque de horario recurrente, ej. "Matemáticas, lunes 7:00-8:30am".
/// `diaSemana` usa el estándar de DateTime: 1 = lunes ... 7 = domingo.
class BloqueHorario {
  final String id;
  final String materiaId;
  final int diaSemana;
  final int horaInicio; // minutos desde medianoche, ej. 7:30am = 450
  final int horaFin;
  final bool notificarInicio;
  final int minutosAntes; // cuánto antes notificar

  const BloqueHorario({
    required this.id,
    required this.materiaId,
    required this.diaSemana,
    required this.horaInicio,
    required this.horaFin,
    this.notificarInicio = true,
    this.minutosAntes = 10,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'materiaId': materiaId,
        'diaSemana': diaSemana,
        'horaInicio': horaInicio,
        'horaFin': horaFin,
        'notificarInicio': notificarInicio ? 1 : 0,
        'minutosAntes': minutosAntes,
      };

  factory BloqueHorario.fromMap(Map<String, dynamic> map) => BloqueHorario(
        id: map['id'] as String,
        materiaId: map['materiaId'] as String,
        diaSemana: map['diaSemana'] as int,
        horaInicio: map['horaInicio'] as int,
        horaFin: map['horaFin'] as int,
        notificarInicio: (map['notificarInicio'] as int) == 1,
        minutosAntes: map['minutosAntes'] as int,
      );
}

/// Evento puntual no recurrente: una prueba, entrega, o fecha importante.
class Recordatorio {
  final String id;
  final String? materiaId;
  final String titulo;
  final DateTime fechaHora;
  final String tipo; // 'prueba', 'entrega', 'evento'
  final String? notas;

  const Recordatorio({
    required this.id,
    this.materiaId,
    required this.titulo,
    required this.fechaHora,
    this.tipo = 'evento',
    this.notas,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'materiaId': materiaId,
        'titulo': titulo,
        'fechaHora': fechaHora.toIso8601String(),
        'tipo': tipo,
        'notas': notas,
      };

  factory Recordatorio.fromMap(Map<String, dynamic> map) => Recordatorio(
        id: map['id'] as String,
        materiaId: map['materiaId'] as String?,
        titulo: map['titulo'] as String,
        fechaHora: DateTime.parse(map['fechaHora'] as String),
        tipo: map['tipo'] as String,
        notas: map['notas'] as String?,
      );
}
