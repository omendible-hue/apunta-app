import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme/app_theme.dart';
import 'screens/root_screen.dart';
import 'services/transcription_service.dart';
import 'services/ai_service.dart';
import 'services/sync_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _inicializarServicios();
  runApp(const ApuntaApp());
}

Future<void> _inicializarServicios() async {
  final p = await SharedPreferences.getInstance();
  final modo        = p.getString('modo_ia') ?? 'groq';
  final groqKey     = p.getString('key_groq') ?? '';
  final geminiKey   = p.getString('key_gemini') ?? '';
  final openAIKey   = p.getString('key_openai') ?? '';
  final anthropicKey= p.getString('key_anthropic') ?? '';

  switch (modo) {
    case 'groq':
      if (groqKey.isNotEmpty) {
        TranscriptionService.instancia.configurar(
            apiKey: groqKey, proveedor: ProveedorTranscripcion.groq);
        AIService.instancia.configurar(
            apiKey: groqKey, proveedor: ProveedorIA.groq);
      }
    case 'gemini':
      if (groqKey.isNotEmpty) {
        TranscriptionService.instancia.configurar(
            apiKey: groqKey, proveedor: ProveedorTranscripcion.groq);
      }
      if (geminiKey.isNotEmpty) {
        AIService.instancia.configurar(
            apiKey: geminiKey, proveedor: ProveedorIA.gemini);
      }
    case 'premium':
      if (openAIKey.isNotEmpty) {
        TranscriptionService.instancia.configurar(
            apiKey: openAIKey, proveedor: ProveedorTranscripcion.openai);
      }
      if (anthropicKey.isNotEmpty) {
        AIService.instancia.configurar(
            apiKey: anthropicKey, proveedor: ProveedorIA.anthropic);
      }
  }

  SyncService.instancia.iniciarEscucha();
}

class ApuntaApp extends StatelessWidget {
  const ApuntaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Apunta',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.tema,
      home: const RootScreen(),
    );
  }
}
