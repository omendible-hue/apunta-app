import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'prueba_grabacion_screen.dart';
import 'horario_screen.dart';
import 'apuntes/apuntes_screen.dart';
import 'ajustes_screen.dart';

/// Pantalla raíz con navegación inferior: Inicio, Apuntes, Horario, Ajustes.
/// Las tres últimas son placeholders por ahora — se construyen en la
/// siguiente vuelta (organizador, horario+notificaciones, exportación).
class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _indice = 0;

  final _pantallas = const [
    HomeScreen(),
    ApuntesScreen(),
    HorarioScreen(),
    AjustesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pantallas[_indice]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _indice,
        onDestinationSelected: (i) => setState(() => _indice = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Inicio'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'Apuntes'),
          NavigationDestination(icon: Icon(Icons.calendar_today_outlined), label: 'Horario'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Ajustes'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Hola 👋', style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 2),
                Text(
                  _fechaDeHoy(),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: AppColors.superficie,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.notifications_outlined,
                  color: AppColors.texto, size: 18),
            ),
          ],
        ),
        const SizedBox(height: 18),
        const _TarjetaProximaClase(
          materia: 'Física II',
          minutosFaltantes: 12,
        ),
        const SizedBox(height: 20),
        Text('Clases recientes', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        const _TarjetaClaseReciente(
          materia: 'Cálculo III',
          estado: 'Guía lista · 3 ejercicios',
          icono: Icons.check,
          colorIcono: AppColors.secundario,
        ),
        const SizedBox(height: 8),
        const _TarjetaClaseReciente(
          materia: 'Historia universal',
          estado: 'Transcribiendo...',
          icono: Icons.access_time,
          colorIcono: AppColors.primario,
        ),
      ],
    );
  }

  String _fechaDeHoy() {
    const dias = [
      'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'
    ];
    const meses = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio',
      'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    final ahora = DateTime.now();
    final dia = dias[ahora.weekday - 1];
    final mes = meses[ahora.month - 1];
    return '${dia[0].toUpperCase()}${dia.substring(1)}, ${ahora.day} de $mes';
  }
}

class _TarjetaProximaClase extends StatelessWidget {
  final String materia;
  final int minutosFaltantes;

  const _TarjetaProximaClase({
    required this.materia,
    required this.minutosFaltantes,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.superficie,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borde),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PRÓXIMA CLASE EN $minutosFaltantes MIN',
            style: const TextStyle(
              color: AppColors.textoSecundario,
              fontSize: 11,
              letterSpacing: 0.6,
            ),
          ),
          const SizedBox(height: 4),
          Text(materia, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 14),
          InkWell(
            borderRadius: BorderRadius.circular(30),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const PruebaGrabacionScreen(),
                ),
              );
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(
                    color: AppColors.grabando,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.mic, color: AppColors.fondo, size: 20),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Grabar ahora',
                  style: TextStyle(
                    color: AppColors.grabando,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TarjetaClaseReciente extends StatelessWidget {
  final String materia;
  final String estado;
  final IconData icono;
  final Color colorIcono;

  const _TarjetaClaseReciente({
    required this.materia,
    required this.estado,
    required this.icono,
    required this.colorIcono,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.superficieAlt,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: colorIcono.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icono, color: colorIcono, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(materia, style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 2),
                Text(estado, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: AppColors.textoTerciario, size: 18),
        ],
      ),
    );
  }
}

class _PlaceholderScreen extends StatelessWidget {
  final String titulo;
  final IconData icono;

  const _PlaceholderScreen({required this.titulo, required this.icono});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icono, color: AppColors.textoTerciario, size: 40),
          const SizedBox(height: 12),
          Text(titulo, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            'Lo construimos en la siguiente vuelta',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
