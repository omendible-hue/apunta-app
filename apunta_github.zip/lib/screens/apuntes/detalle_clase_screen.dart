import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';
import '../../theme/app_theme.dart';
import '../../models/clase.dart';
import '../../models/materia.dart';
import '../../services/db_service.dart';
import '../../services/export_service.dart';
import '../../widgets/estado_chip.dart';

const _uuid = Uuid();

/// Detalle completo de una clase grabada.
/// Muestra: guía de estudio generada por IA, ejercicios, fotos del pizarrón.
/// Permite: tomar fotos nuevas del pizarrón o subirlas desde la galería.
class DetalleClaseScreen extends StatefulWidget {
  final Clase clase;
  final Materia? materia;

  const DetalleClaseScreen({super.key, required this.clase, this.materia});

  @override
  State<DetalleClaseScreen> createState() => _DetalleClaseScreenState();
}

class _DetalleClaseScreenState extends State<DetalleClaseScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  late Clase _clase;
  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _clase = widget.clase;
    // Guía | Ejercicios | Fotos
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _capturarFoto(ImageSource source) async {
    final picked = await _picker.pickImage(
      source: source,
      imageQuality: 85,
      maxWidth: 2048,
    );
    if (picked == null) return;

    // Copiar al directorio interno de la app para persistencia
    final dir = await getApplicationDocumentsDirectory();
    final fotoDir = Directory(p.join(dir.path, 'fotos'));
    await fotoDir.create(recursive: true);
    final destino = p.join(fotoDir.path, '${_uuid.v4()}.jpg');
    await File(picked.path).copy(destino);

    final nuevasRutas = [..._clase.rutasFotos, destino];
    final claseActualizada = _clase.copyWith(rutasFotos: nuevasRutas);
    await DBService.instancia.guardarClase(claseActualizada);
    setState(() => _clase = claseActualizada);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Foto guardada en tus apuntes'),
          backgroundColor: AppColors.secundario,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _mostrarOpcionesFoto() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.superficie,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined,
                  color: AppColors.primario),
              title: const Text('Tomar foto del pizarrón',
                  style: TextStyle(color: AppColors.texto)),
              onTap: () {
                Navigator.pop(context);
                _capturarFoto(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined,
                  color: AppColors.primario),
              title: const Text('Elegir de la galería',
                  style: TextStyle(color: AppColors.texto)),
              onTap: () {
                Navigator.pop(context);
                _capturarFoto(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  bool _exportando = false;

  Future<void> _exportar() async {
    if (_exportando) return;
    if (_clase.estado != EstadoClase.lista) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('La guía aún no está lista. Espera a que termine de procesarse.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    setState(() => _exportando = true);
    try {
      await ExportService.instancia.exportarYCompartir(
        clase: _clase,
        materia: widget.materia,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al exportar: $e'),
            backgroundColor: AppColors.detener,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _exportando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.materia != null
        ? Color(widget.materia!.colorHex)
        : AppColors.primario;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.materia?.nombre ?? 'Clase'),
        actions: [
          // Botón de exportar PDF
          if (_exportando)
            const Padding(
              padding: EdgeInsets.all(14),
              child: SizedBox(
                width: 20, height: 20,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: AppColors.texto),
              ),
            )
          else
            IconButton(
              icon: const Icon(Icons.ios_share_outlined),
              tooltip: 'Exportar PDF',
              onPressed: _exportar,
            ),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: EstadoChip(estado: _clase.estado),
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: color,
          labelColor: color,
          unselectedLabelColor: AppColors.textoTerciario,
          tabs: const [
            Tab(text: 'Guía'),
            Tab(text: 'Ejercicios'),
            Tab(text: 'Fotos'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _TabGuia(clase: _clase),
          _TabEjercicios(clase: _clase),
          _TabFotos(
            clase: _clase,
            onAgregarFoto: _mostrarOpcionesFoto,
          ),
        ],
      ),
    );
  }
}

// ---------- Tab: Guía de estudio ----------

class _TabGuia extends StatelessWidget {
  final Clase clase;
  const _TabGuia({required this.clase});

  @override
  Widget build(BuildContext context) {
    if (clase.estado == EstadoClase.grabada ||
        clase.estado == EstadoClase.sincronizando ||
        clase.estado == EstadoClase.transcribiendo) {
      return const _EstadoProcesando(
        mensaje: 'Generando tu guía de estudio...',
        detalle:
            'La IA está transcribiendo el audio e investigando el tema. Puede tomar unos minutos.',
      );
    }

    if (clase.guiaEstudio == null) {
      return Center(
        child: Text(
          'Guía no disponible',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        // Renderizado simple de Markdown (negritas y secciones)
        _MarkdownSimple(texto: clase.guiaEstudio!),
      ],
    );
  }
}

// ---------- Tab: Ejercicios ----------

class _TabEjercicios extends StatelessWidget {
  final Clase clase;
  const _TabEjercicios({required this.clase});

  @override
  Widget build(BuildContext context) {
    if (clase.ejercicios == null) {
      return const _EstadoProcesando(
        mensaje: 'Los ejercicios aún no están listos',
        detalle: 'Se generan junto con la guía de estudio.',
      );
    }
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [_MarkdownSimple(texto: clase.ejercicios!)],
    );
  }
}

// ---------- Tab: Fotos del pizarrón ----------

class _TabFotos extends StatelessWidget {
  final Clase clase;
  final VoidCallback onAgregarFoto;

  const _TabFotos({required this.clase, required this.onAgregarFoto});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        clase.rutasFotos.isEmpty
            ? Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.camera_alt_outlined,
                        color: AppColors.textoTerciario, size: 40),
                    const SizedBox(height: 12),
                    Text('Sin fotos del pizarrón',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Text('Toca + para agregar una foto',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              )
            : GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: clase.rutasFotos.length,
                itemBuilder: (context, i) {
                  final ruta = clase.rutasFotos[i];
                  return GestureDetector(
                    onTap: () => _verFotoCompleta(context, ruta),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(
                        File(ruta),
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: AppColors.superficie,
                          child: const Icon(Icons.broken_image_outlined,
                              color: AppColors.textoTerciario),
                        ),
                      ),
                    ),
                  );
                },
              ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            backgroundColor: AppColors.primario,
            onPressed: onAgregarFoto,
            child: const Icon(Icons.add_a_photo_outlined, color: AppColors.texto),
          ),
        ),
      ],
    );
  }

  void _verFotoCompleta(BuildContext context, String ruta) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: const EdgeInsets.all(12),
        child: InteractiveViewer(
          child: Image.file(File(ruta)),
        ),
      ),
    );
  }
}

// ---------- Helpers ----------

class _EstadoProcesando extends StatelessWidget {
  final String mensaje;
  final String detalle;
  const _EstadoProcesando({required this.mensaje, required this.detalle});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: AppColors.primario),
            const SizedBox(height: 20),
            Text(mensaje, style: Theme.of(context).textTheme.titleMedium,
                textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(detalle, style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

/// Renderizador minimalista de Markdown: soporta # títulos y **negrita**.
/// Para producción se puede reemplazar con el paquete `flutter_markdown`.
class _MarkdownSimple extends StatelessWidget {
  final String texto;
  const _MarkdownSimple({required this.texto});

  @override
  Widget build(BuildContext context) {
    final lineas = texto.split('\n');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: lineas.map((linea) {
        if (linea.startsWith('## ')) {
          return Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 4),
            child: Text(linea.substring(3),
                style: Theme.of(context).textTheme.titleMedium),
          );
        }
        if (linea.startsWith('# ')) {
          return Padding(
            padding: const EdgeInsets.only(top: 20, bottom: 6),
            child: Text(linea.substring(2),
                style: Theme.of(context).textTheme.headlineSmall),
          );
        }
        if (linea.trim().isEmpty) {
          return const SizedBox(height: 8);
        }
        // Negrita simple: reemplaza **texto** por negrita
        return Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: _TextoConNegrita(texto: linea),
        );
      }).toList(),
    );
  }
}

class _TextoConNegrita extends StatelessWidget {
  final String texto;
  const _TextoConNegrita({required this.texto});

  @override
  Widget build(BuildContext context) {
    final partes = texto.split('**');
    final spans = <TextSpan>[];
    for (var i = 0; i < partes.length; i++) {
      if (partes[i].isEmpty) continue;
      spans.add(TextSpan(
        text: partes[i],
        style: i.isOdd
            ? const TextStyle(
                fontWeight: FontWeight.bold, color: AppColors.texto)
            : const TextStyle(color: AppColors.textoSecundario),
      ));
    }
    return RichText(
      text: TextSpan(children: spans),
    );
  }
}
