import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/materia.dart';
import '../../models/clase.dart';
import '../../services/db_service.dart';
import '../../widgets/estado_chip.dart';
import 'detalle_clase_screen.dart';

/// Pantalla de Apuntes: muestra las materias como secciones colapsables,
/// con las clases grabadas ordenadas del más reciente al más antiguo.
/// El filtro superior permite ver Todo, Esta semana, o por materia.
class ApuntesScreen extends StatefulWidget {
  const ApuntesScreen({super.key});

  @override
  State<ApuntesScreen> createState() => _ApuntesScreenState();
}

class _ApuntesScreenState extends State<ApuntesScreen> {
  List<Materia> _materias = [];
  List<Clase> _clases = [];
  String? _filtroMateriaId; // null = todas
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final db = DBService.instancia;
    final materias = await db.listarMaterias();
    final clases = await db.listarClases();
    setState(() {
      _materias = materias;
      _clases = clases;
      _cargando = false;
    });
  }

  List<Clase> get _clasesFiltradas {
    if (_filtroMateriaId == null) return _clases;
    return _clases.where((c) => c.materiaId == _filtroMateriaId).toList();
  }

  Materia? _materiaDe(Clase c) {
    for (final m in _materias) {
      if (m.id == c.materiaId) return m;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_materias.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.folder_outlined,
                color: AppColors.textoTerciario, size: 40),
            const SizedBox(height: 12),
            Text('Sin apuntes todavía',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              'Graba tu primera clase para que aparezca aquí',
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // ---------- Encabezado + filtro ----------
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Apuntes',
                  style: Theme.of(context).textTheme.headlineSmall),
              Text(
                '${_clasesFiltradas.length} clase${_clasesFiltradas.length == 1 ? '' : 's'}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
        // Filtro horizontal por materia
        SizedBox(
          height: 36,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              _ChipFiltro(
                etiqueta: 'Todas',
                seleccionado: _filtroMateriaId == null,
                onTap: () => setState(() => _filtroMateriaId = null),
              ),
              ..._materias.map((m) => _ChipFiltro(
                    etiqueta: m.nombre,
                    seleccionado: _filtroMateriaId == m.id,
                    color: Color(m.colorHex),
                    onTap: () => setState(() => _filtroMateriaId = m.id),
                  )),
            ],
          ),
        ),
        const SizedBox(height: 8),
        // ---------- Lista de clases ----------
        Expanded(
          child: _clasesFiltradas.isEmpty
              ? Center(
                  child: Text('Nada en esta materia todavía',
                      style: Theme.of(context).textTheme.bodySmall),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  itemCount: _clasesFiltradas.length,
                  itemBuilder: (context, i) {
                    final clase = _clasesFiltradas[i];
                    final materia = _materiaDe(clase);
                    return _TarjetaClase(
                      clase: clase,
                      materia: materia,
                      onTap: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => DetalleClaseScreen(
                            clase: clase,
                            materia: materia,
                          ),
                        ));
                        _cargar(); // recargar por si hubo cambios
                      },
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _ChipFiltro extends StatelessWidget {
  final String etiqueta;
  final bool seleccionado;
  final Color? color;
  final VoidCallback onTap;

  const _ChipFiltro({
    required this.etiqueta,
    required this.seleccionado,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primario;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: seleccionado ? c.withOpacity(0.2) : AppColors.superficie,
          borderRadius: BorderRadius.circular(20),
          border: seleccionado
              ? Border.all(color: c, width: 1.5)
              : Border.all(color: AppColors.borde, width: 1),
        ),
        child: Text(
          etiqueta,
          style: TextStyle(
            fontSize: 12,
            color: seleccionado ? c : AppColors.textoSecundario,
            fontWeight: seleccionado ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}

class _TarjetaClase extends StatelessWidget {
  final Clase clase;
  final Materia? materia;
  final VoidCallback onTap;

  const _TarjetaClase(
      {required this.clase, required this.materia, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color =
        materia != null ? Color(materia!.colorHex) : AppColors.primario;
    final fecha = clase.fecha;
    final duracion = clase.duracionSegundos != null
        ? _formatDuracion(clase.duracionSegundos!)
        : null;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: AppColors.superficieAlt,
          borderRadius: BorderRadius.circular(16),
          border: Border(left: BorderSide(color: color, width: 3)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    materia?.nombre ?? 'Sin materia',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  EstadoChip(estado: clase.estado),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Icon(Icons.calendar_today_outlined,
                      size: 12, color: AppColors.textoTerciario),
                  const SizedBox(width: 4),
                  Text(_formatFecha(fecha),
                      style: Theme.of(context).textTheme.bodySmall),
                  if (duracion != null) ...[
                    const SizedBox(width: 12),
                    const Icon(Icons.timer_outlined,
                        size: 12, color: AppColors.textoTerciario),
                    const SizedBox(width: 4),
                    Text(duracion,
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                  if (clase.rutasFotos.isNotEmpty) ...[
                    const SizedBox(width: 12),
                    const Icon(Icons.photo_camera_outlined,
                        size: 12, color: AppColors.textoTerciario),
                    const SizedBox(width: 4),
                    Text('${clase.rutasFotos.length} foto${clase.rutasFotos.length > 1 ? 's' : ''}',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ],
              ),
              if (clase.guiaEstudio != null) ...[
                const SizedBox(height: 8),
                Text(
                  _resumenGuia(clase.guiaEstudio!),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: AppColors.textoSecundario),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _formatFecha(DateTime f) {
    const meses = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
    return '${f.day} ${meses[f.month - 1]} · ${f.hour}:${f.minute.toString().padLeft(2,'0')}';
  }

  String _formatDuracion(int segundos) {
    final m = segundos ~/ 60;
    final s = segundos % 60;
    return m > 0 ? '${m}m ${s}s' : '${s}s';
  }

  String _resumenGuia(String guia) {
    final lineas = guia.split('\n').where((l) => l.trim().isNotEmpty).toList();
    return lineas.take(2).join(' · ');
  }
}
