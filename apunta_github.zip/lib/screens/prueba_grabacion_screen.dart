import 'package:flutter/material.dart';
import '../services/recording_service.dart';

/// Pantalla mínima de validación: solo confirma que el servicio nativo
/// graba correctamente en segundo plano. Esta es la PRUEBA DE FUEGO antes
/// de construir el resto de la app encima.
class PruebaGrabacionScreen extends StatefulWidget {
  const PruebaGrabacionScreen({super.key});

  @override
  State<PruebaGrabacionScreen> createState() => _PruebaGrabacionScreenState();
}

class _PruebaGrabacionScreenState extends State<PruebaGrabacionScreen> {
  bool _grabando = false;
  DateTime? _inicio;
  String _mensaje = '';

  Future<void> _alternarGrabacion() async {
    if (_grabando) {
      await RecordingService.detener();
      setState(() {
        _grabando = false;
        _mensaje = 'Grabación detenida. Revisa la carpeta interna de la app '
            '(files/grabaciones) para confirmar que el .m4a se guardó.';
      });
    } else {
      final ok = await RecordingService.iniciar('Prueba');
      if (!ok) {
        setState(() {
          _mensaje = 'Permiso de micrófono denegado. Actívalo desde '
              'Ajustes > Apps > Class Tracker > Permisos.';
        });
        return;
      }
      setState(() {
        _grabando = true;
        _inicio = DateTime.now();
        _mensaje = 'Grabando. Apaga la pantalla y guarda el teléfono en el '
            'bolso unos minutos — eso es justo lo que estamos validando.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Class Tracker',
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                'Prueba de grabación en segundo plano',
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
              const SizedBox(height: 64),
              GestureDetector(
                onTap: _alternarGrabacion,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _grabando ? cs.error : cs.primary,
                    boxShadow: [
                      BoxShadow(
                        color: (_grabando ? cs.error : cs.primary)
                            .withOpacity(0.4),
                        blurRadius: 30,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: Icon(
                    _grabando ? Icons.stop_rounded : Icons.mic_rounded,
                    color: Colors.white,
                    size: 56,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              if (_grabando && _inicio != null)
                _ContadorTiempo(inicio: _inicio!),
              const SizedBox(height: 24),
              if (_mensaje.isNotEmpty)
                Text(
                  _mensaje,
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: cs.onSurfaceVariant),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ContadorTiempo extends StatefulWidget {
  final DateTime inicio;
  const _ContadorTiempo({required this.inicio});

  @override
  State<_ContadorTiempo> createState() => _ContadorTiempoState();
}

class _ContadorTiempoState extends State<_ContadorTiempo> {
  late Duration _transcurrido;
  @override
  void initState() {
    super.initState();
    _transcurrido = DateTime.now().difference(widget.inicio);
    _tick();
  }

  void _tick() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() => _transcurrido = DateTime.now().difference(widget.inicio));
      _tick();
    });
  }

  @override
  Widget build(BuildContext context) {
    final m = _transcurrido.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = _transcurrido.inSeconds.remainder(60).toString().padLeft(2, '0');
    return Text(
      '$m:$s',
      style: Theme.of(context).textTheme.headlineSmall,
    );
  }
}
