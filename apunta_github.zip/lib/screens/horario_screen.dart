import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../theme/app_theme.dart';
import '../models/materia.dart';
import '../models/horario.dart';
import '../services/db_service.dart';
import '../services/notification_service.dart';

const _diasSemana = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
const _uuid = Uuid();

// Paleta de colores disponible para asignar a materias nuevas.
const _coloresMateria = [
  AppColors.primario,
  AppColors.secundario,
  AppColors.grabando,
  Color(0xFFD4537E), // pink
  Color(0xFF378ADD), // blue
];

class HorarioScreen extends StatefulWidget {
  const HorarioScreen({super.key});

  @override
  State<HorarioScreen> createState() => _HorarioScreenState();
}

class _HorarioScreenState extends State<HorarioScreen> {
  List<Materia> _materias = [];
  List<BloqueHorario> _bloques = [];
  List<Recordatorio> _recordatorios = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargarTodo();
  }

  Future<void> _cargarTodo() async {
    final db = DBService.instancia;
    final materias = await db.listarMaterias();
    final bloques = await db.listarBloques();
    final recordatorios = await db.listarRecordatorios();
    setState(() {
      _materias = materias;
      _bloques = bloques;
      _recordatorios = recordatorios
          .where((r) => r.fechaHora.isAfter(
              DateTime.now().subtract(const Duration(days: 1))))
          .toList();
      _cargando = false;
    });
  }

  Materia? _materiaPorId(String id) {
    for (final m in _materias) {
      if (m.id == id) return m;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_materias.isEmpty) {
      return _EstadoVacio(onCrearMateria: _abrirFormularioMateria);
    }

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Horario', style: Theme.of(context).textTheme.headlineSmall),
                IconButton(
                  onPressed: _abrirFormularioMateria,
                  icon: const Icon(Icons.person_add_alt_outlined,
                      color: AppColors.textoSecundario, size: 20),
                  tooltip: 'Nueva materia',
                ),
              ],
            ),
            const SizedBox(height: 12),
            _VistaSemana(
              bloques: _bloques,
              materiaPorId: _materiaPorId,
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Próximas fechas importantes',
                    style: Theme.of(context).textTheme.titleMedium),
                IconButton(
                  onPressed: _abrirFormularioRecordatorio,
                  icon: const Icon(Icons.add, color: AppColors.textoSecundario, size: 20),
                  tooltip: 'Nuevo recordatorio',
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_recordatorios.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text('Nada programado todavía',
                    style: Theme.of(context).textTheme.bodySmall),
              )
            else
              ..._recordatorios.map((r) => _TarjetaRecordatorio(
                    recordatorio: r,
                    materia: r.materiaId != null ? _materiaPorId(r.materiaId!) : null,
                  )),
          ],
        ),
        Positioned(
          right: 0,
          bottom: 8,
          child: FloatingActionButton(
            backgroundColor: AppColors.primario,
            onPressed: _abrirFormularioBloque,
            child: const Icon(Icons.add, color: AppColors.texto),
          ),
        ),
      ],
    );
  }

  Future<void> _abrirFormularioMateria() async {
    final resultado = await showModalBottomSheet<Materia>(
      context: context,
      backgroundColor: AppColors.superficie,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => const _FormularioMateria(),
    );
    if (resultado != null) {
      await DBService.instancia.guardarMateria(resultado);
      await _cargarTodo();
    }
  }

  Future<void> _abrirFormularioBloque() async {
    if (_materias.isEmpty) {
      await _abrirFormularioMateria();
      if (_materias.isEmpty) return;
    }
    final resultado = await showModalBottomSheet<BloqueHorario>(
      context: context,
      backgroundColor: AppColors.superficie,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _FormularioBloque(materias: _materias),
    );
    if (resultado != null) {
      await DBService.instancia.guardarBloque(resultado);
      final materia = _materiaPorId(resultado.materiaId);
      if (materia != null) {
        await NotificationService.instancia.programarBloque(resultado, materia);
      }
      await _cargarTodo();
    }
  }

  Future<void> _abrirFormularioRecordatorio() async {
    final resultado = await showModalBottomSheet<Recordatorio>(
      context: context,
      backgroundColor: AppColors.superficie,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _FormularioRecordatorio(materias: _materias),
    );
    if (resultado != null) {
      await DBService.instancia.guardarRecordatorio(resultado);
      await NotificationService.instancia.programarRecordatorio(resultado);
      await _cargarTodo();
    }
  }
}

class _EstadoVacio extends StatelessWidget {
  final VoidCallback onCrearMateria;
  const _EstadoVacio({required this.onCrearMateria});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.calendar_today_outlined,
                color: AppColors.textoTerciario, size: 40),
            const SizedBox(height: 12),
            Text('Aún no tienes materias',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              'Crea tu primera materia para armar el horario',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: onCrearMateria,
              style: FilledButton.styleFrom(backgroundColor: AppColors.primario),
              child: const Text('Crear materia'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Vista semanal compacta: una columna por día, bloques apilados según
/// su hora de inicio relativa dentro del rango de horas con clases.
class _VistaSemana extends StatelessWidget {
  final List<BloqueHorario> bloques;
  final Materia? Function(String) materiaPorId;

  const _VistaSemana({required this.bloques, required this.materiaPorId});

  @override
  Widget build(BuildContext context) {
    if (bloques.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.superficie,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          'Agrega bloques de clase con el botón + para verlos aquí',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.superficie,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: List.generate(7, (i) {
          final diaNum = i + 1;
          final bloquesDelDia = bloques.where((b) => b.diaSemana == diaNum).toList()
            ..sort((a, b) => a.horaInicio.compareTo(b.horaInicio));
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Column(
                children: [
                  Text(_diasSemana[i],
                      style: const TextStyle(
                          color: AppColors.textoSecundario, fontSize: 11)),
                  const SizedBox(height: 8),
                  ...bloquesDelDia.map((b) {
                    final materia = materiaPorId(b.materiaId);
                    final color =
                        materia != null ? Color(materia.colorHex) : AppColors.primario;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(8),
                        border: Border(left: BorderSide(color: color, width: 2.5)),
                      ),
                      child: Column(
                        children: [
                          Text(
                            materia?.nombre ?? '?',
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 10, color: AppColors.texto),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _formatearHora(b.horaInicio),
                            style: const TextStyle(
                                fontSize: 9, color: AppColors.textoTerciario),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}

String _formatearHora(int minutosDesdeMedianoche) {
  final h = minutosDesdeMedianoche ~/ 60;
  final m = minutosDesdeMedianoche % 60;
  final h12 = h % 12 == 0 ? 12 : h % 12;
  final ampm = h < 12 ? 'am' : 'pm';
  return '$h12:${m.toString().padLeft(2, '0')}$ampm';
}

class _TarjetaRecordatorio extends StatelessWidget {
  final Recordatorio recordatorio;
  final Materia? materia;

  const _TarjetaRecordatorio({required this.recordatorio, this.materia});

  @override
  Widget build(BuildContext context) {
    final icono = switch (recordatorio.tipo) {
      'prueba' => Icons.edit_note,
      'entrega' => Icons.upload_file_outlined,
      _ => Icons.event_outlined,
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.superficieAlt,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: AppColors.grabando.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icono, color: AppColors.grabando, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(recordatorio.titulo, style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 2),
                Text(
                  '${materia != null ? '${materia!.nombre} · ' : ''}${_formatearFechaCorta(recordatorio.fechaHora)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String _formatearFechaCorta(DateTime f) {
  const meses = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  return '${f.day} ${meses[f.month - 1]}, ${_formatearHora(f.hour * 60 + f.minute)}';
}

// ---------------- Formularios ----------------

class _FormularioMateria extends StatefulWidget {
  const _FormularioMateria();

  @override
  State<_FormularioMateria> createState() => _FormularioMateriaState();
}

class _FormularioMateriaState extends State<_FormularioMateria> {
  final _nombreCtrl = TextEditingController();
  final _profesorCtrl = TextEditingController();
  final _aulaCtrl = TextEditingController();
  int _colorSeleccionado = 0;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Nueva materia', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          TextField(
            controller: _nombreCtrl,
            decoration: const InputDecoration(labelText: 'Nombre de la materia'),
            autofocus: true,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _profesorCtrl,
            decoration: const InputDecoration(labelText: 'Profesor (opcional)'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _aulaCtrl,
            decoration: const InputDecoration(labelText: 'Aula (opcional)'),
          ),
          const SizedBox(height: 16),
          Row(
            children: List.generate(_coloresMateria.length, (i) {
              final seleccionado = i == _colorSeleccionado;
              return Padding(
                padding: const EdgeInsets.only(right: 10),
                child: GestureDetector(
                  onTap: () => setState(() => _colorSeleccionado = i),
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: _coloresMateria[i],
                      shape: BoxShape.circle,
                      border: seleccionado
                          ? Border.all(color: AppColors.texto, width: 2)
                          : null,
                    ),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.primario),
              onPressed: () {
                if (_nombreCtrl.text.trim().isEmpty) return;
                Navigator.of(context).pop(Materia(
                  id: _uuid.v4(),
                  nombre: _nombreCtrl.text.trim(),
                  colorHex: _coloresMateria[_colorSeleccionado].toARGB32(),
                  profesor: _profesorCtrl.text.trim().isEmpty ? null : _profesorCtrl.text.trim(),
                  aula: _aulaCtrl.text.trim().isEmpty ? null : _aulaCtrl.text.trim(),
                ));
              },
              child: const Text('Guardar'),
            ),
          ),
        ],
      ),
    );
  }
}

class _FormularioBloque extends StatefulWidget {
  final List<Materia> materias;
  const _FormularioBloque({required this.materias});

  @override
  State<_FormularioBloque> createState() => _FormularioBloqueState();
}

class _FormularioBloqueState extends State<_FormularioBloque> {
  late String _materiaId = widget.materias.first.id;
  int _diaSemana = 1;
  TimeOfDay _inicio = const TimeOfDay(hour: 7, minute: 0);
  TimeOfDay _fin = const TimeOfDay(hour: 8, minute: 30);
  int _minutosAntes = 10;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Nuevo bloque de clase', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            initialValue: _materiaId,
            decoration: const InputDecoration(labelText: 'Materia'),
            items: widget.materias
                .map((m) => DropdownMenuItem(value: m.id, child: Text(m.nombre)))
                .toList(),
            onChanged: (v) => setState(() => _materiaId = v!),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 6,
            children: List.generate(7, (i) {
              final dia = i + 1;
              final seleccionado = dia == _diaSemana;
              return ChoiceChip(
                label: Text(_diasSemana[i]),
                selected: seleccionado,
                selectedColor: AppColors.primario,
                onSelected: (_) => setState(() => _diaSemana = dia),
              );
            }),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SelectorHora(
                  etiqueta: 'Inicio',
                  hora: _inicio,
                  onCambiar: (h) => setState(() => _inicio = h),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SelectorHora(
                  etiqueta: 'Fin',
                  hora: _fin,
                  onCambiar: (h) => setState(() => _fin = h),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            initialValue: _minutosAntes,
            decoration: const InputDecoration(labelText: 'Notificar antes'),
            items: const [5, 10, 15, 30]
                .map((m) => DropdownMenuItem(value: m, child: Text('$m minutos')))
                .toList(),
            onChanged: (v) => setState(() => _minutosAntes = v!),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.primario),
              onPressed: () {
                Navigator.of(context).pop(BloqueHorario(
                  id: _uuid.v4(),
                  materiaId: _materiaId,
                  diaSemana: _diaSemana,
                  horaInicio: _inicio.hour * 60 + _inicio.minute,
                  horaFin: _fin.hour * 60 + _fin.minute,
                  minutosAntes: _minutosAntes,
                ));
              },
              child: const Text('Guardar'),
            ),
          ),
        ],
      ),
    );
  }
}

class _SelectorHora extends StatelessWidget {
  final String etiqueta;
  final TimeOfDay hora;
  final ValueChanged<TimeOfDay> onCambiar;

  const _SelectorHora({required this.etiqueta, required this.hora, required this.onCambiar});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        final seleccionada = await showTimePicker(context: context, initialTime: hora);
        if (seleccionada != null) onCambiar(seleccionada);
      },
      child: InputDecorator(
        decoration: InputDecoration(labelText: etiqueta),
        child: Text(hora.format(context)),
      ),
    );
  }
}

class _FormularioRecordatorio extends StatefulWidget {
  final List<Materia> materias;
  const _FormularioRecordatorio({required this.materias});

  @override
  State<_FormularioRecordatorio> createState() => _FormularioRecordatorioState();
}

class _FormularioRecordatorioState extends State<_FormularioRecordatorio> {
  final _tituloCtrl = TextEditingController();
  String? _materiaId;
  String _tipo = 'prueba';
  DateTime _fecha = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _hora = const TimeOfDay(hour: 9, minute: 0);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Nuevo recordatorio', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          TextField(
            controller: _tituloCtrl,
            decoration: const InputDecoration(labelText: 'Título (ej. Parcial de Física)'),
            autofocus: true,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 6,
            children: [
              ChoiceChip(
                label: const Text('Prueba'),
                selected: _tipo == 'prueba',
                selectedColor: AppColors.primario,
                onSelected: (_) => setState(() => _tipo = 'prueba'),
              ),
              ChoiceChip(
                label: const Text('Entrega'),
                selected: _tipo == 'entrega',
                selectedColor: AppColors.primario,
                onSelected: (_) => setState(() => _tipo = 'entrega'),
              ),
              ChoiceChip(
                label: const Text('Evento'),
                selected: _tipo == 'evento',
                selectedColor: AppColors.primario,
                onSelected: (_) => setState(() => _tipo = 'evento'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (widget.materias.isNotEmpty)
            DropdownButtonFormField<String?>(
              initialValue: _materiaId,
              decoration: const InputDecoration(labelText: 'Materia (opcional)'),
              items: [
                const DropdownMenuItem(value: null, child: Text('Ninguna')),
                ...widget.materias
                    .map((m) => DropdownMenuItem(value: m.id, child: Text(m.nombre))),
              ],
              onChanged: (v) => setState(() => _materiaId = v),
            ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () async {
                    final seleccionada = await showDatePicker(
                      context: context,
                      initialDate: _fecha,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (seleccionada != null) setState(() => _fecha = seleccionada);
                  },
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'Fecha'),
                    child: Text('${_fecha.day}/${_fecha.month}/${_fecha.year}'),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SelectorHora(
                  etiqueta: 'Hora',
                  hora: _hora,
                  onCambiar: (h) => setState(() => _hora = h),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.primario),
              onPressed: () {
                if (_tituloCtrl.text.trim().isEmpty) return;
                final fechaHora = DateTime(
                  _fecha.year, _fecha.month, _fecha.day, _hora.hour, _hora.minute,
                );
                Navigator.of(context).pop(Recordatorio(
                  id: _uuid.v4(),
                  materiaId: _materiaId,
                  titulo: _tituloCtrl.text.trim(),
                  fechaHora: fechaHora,
                  tipo: _tipo,
                ));
              },
              child: const Text('Guardar'),
            ),
          ),
        ],
      ),
    );
  }
}
