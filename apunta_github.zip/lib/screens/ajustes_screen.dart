import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import '../services/transcription_service.dart';
import '../services/ai_service.dart';
import '../services/sync_service.dart';

class AjustesScreen extends StatefulWidget {
  const AjustesScreen({super.key});

  @override
  State<AjustesScreen> createState() => _AjustesScreenState();
}

class _AjustesScreenState extends State<AjustesScreen> {
  // Claves de almacenamiento
  static const _kModo         = 'modo_ia';       // 'groq', 'gemini', 'premium'
  static const _kGroqKey      = 'key_groq';
  static const _kGeminiKey    = 'key_gemini';
  static const _kOpenAIKey    = 'key_openai';
  static const _kAnthropicKey = 'key_anthropic';

  final _groqCtrl      = TextEditingController();
  final _geminiCtrl    = TextEditingController();
  final _openAICtrl    = TextEditingController();
  final _anthropicCtrl = TextEditingController();

  String _modo = 'groq'; // 'groq' | 'gemini' | 'premium'
  bool _guardando = false;
  bool _cargado = false;

  // Visibilidad de cada campo
  final _ver = {'groq': false, 'gemini': false, 'openai': false, 'anthropic': false};

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _modo             = p.getString(_kModo) ?? 'groq';
      _groqCtrl.text      = p.getString(_kGroqKey) ?? '';
      _geminiCtrl.text    = p.getString(_kGeminiKey) ?? '';
      _openAICtrl.text    = p.getString(_kOpenAIKey) ?? '';
      _anthropicCtrl.text = p.getString(_kAnthropicKey) ?? '';
      _cargado = true;
    });
    _aplicar();
  }

  void _aplicar() {
    switch (_modo) {
      case 'groq':
        if (_groqCtrl.text.isNotEmpty) {
          TranscriptionService.instancia.configurar(
            apiKey: _groqCtrl.text,
            proveedor: ProveedorTranscripcion.groq,
          );
          AIService.instancia.configurar(
            apiKey: _groqCtrl.text,
            proveedor: ProveedorIA.groq,
          );
        }
      case 'gemini':
        if (_groqCtrl.text.isNotEmpty) {
          TranscriptionService.instancia.configurar(
            apiKey: _groqCtrl.text,
            proveedor: ProveedorTranscripcion.groq,
          );
        }
        if (_geminiCtrl.text.isNotEmpty) {
          AIService.instancia.configurar(
            apiKey: _geminiCtrl.text,
            proveedor: ProveedorIA.gemini,
          );
        }
      case 'premium':
        if (_openAICtrl.text.isNotEmpty) {
          TranscriptionService.instancia.configurar(
            apiKey: _openAICtrl.text,
            proveedor: ProveedorTranscripcion.openai,
          );
        }
        if (_anthropicCtrl.text.isNotEmpty) {
          AIService.instancia.configurar(
            apiKey: _anthropicCtrl.text,
            proveedor: ProveedorIA.anthropic,
          );
        }
    }
  }

  Future<void> _guardar() async {
    setState(() => _guardando = true);
    final p = await SharedPreferences.getInstance();
    await p.setString(_kModo,         _modo);
    await p.setString(_kGroqKey,      _groqCtrl.text.trim());
    await p.setString(_kGeminiKey,    _geminiCtrl.text.trim());
    await p.setString(_kOpenAIKey,    _openAICtrl.text.trim());
    await p.setString(_kAnthropicKey, _anthropicCtrl.text.trim());
    _aplicar();

    if (TranscriptionService.instancia.estaConfigurado &&
        AIService.instancia.estaConfigurado) {
      SyncService.instancia.procesarCola();
    }

    setState(() => _guardando = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Configuración guardada ✓'),
        backgroundColor: AppColors.secundario,
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_cargado) return const Center(child: CircularProgressIndicator());

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Ajustes', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 4),
        Text('Las claves se guardan solo en tu teléfono.',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 24),

        // ── Selector de modo ─────────────────────────────────────────────
        Text('Modo de procesamiento',
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        _SelectorModo(
          modoActual: _modo,
          onCambiar: (m) => setState(() => _modo = m),
        ),
        const SizedBox(height: 20),

        // ── Formulario según el modo ─────────────────────────────────────
        if (_modo == 'groq') ...[
          _InfoServicio(
            titulo: 'Groq — Completamente gratuito',
            descripcion:
                'Una sola clave para transcripción (Whisper) y guía de estudio '
                '(Llama 3.3). Sin tarjeta de crédito.\n\n'
                '📌 Cómo obtenerla:\n'
                '1. Ve a console.groq.com\n'
                '2. Crea cuenta con tu email\n'
                '3. API Keys → Create API Key\n'
                '4. Copia y pega aquí',
            color: const Color(0xFFF55036),
            icono: Icons.bolt_outlined,
          ),
          const SizedBox(height: 12),
          _CampoApiKey(
            label: 'Clave de Groq',
            hint: 'gsk_...',
            ctrl: _groqCtrl,
            visible: _ver['groq']!,
            onToggleVer: () => setState(() => _ver['groq'] = !_ver['groq']!),
          ),
        ],

        if (_modo == 'gemini') ...[
          _InfoServicio(
            titulo: 'Google Gemini — Gratuito',
            descripcion:
                'Groq para transcripción + Gemini para la guía de estudio. '
                'Gemini tiene una capa gratuita generosa.\n\n'
                '📌 Cómo obtener la clave de Gemini:\n'
                '1. Ve a aistudio.google.com\n'
                '2. Inicia sesión con tu cuenta Google\n'
                '3. "Get API Key" → Create API Key\n'
                '4. Copia y pega aquí\n\n'
                'También necesitas la clave de Groq para la transcripción.',
            color: const Color(0xFF4285F4),
            icono: Icons.auto_awesome_outlined,
          ),
          const SizedBox(height: 12),
          _CampoApiKey(
            label: 'Clave de Groq (transcripción)',
            hint: 'gsk_...',
            ctrl: _groqCtrl,
            visible: _ver['groq']!,
            onToggleVer: () => setState(() => _ver['groq'] = !_ver['groq']!),
          ),
          const SizedBox(height: 10),
          _CampoApiKey(
            label: 'Clave de Google Gemini (guía)',
            hint: 'AIza...',
            ctrl: _geminiCtrl,
            visible: _ver['gemini']!,
            onToggleVer: () =>
                setState(() => _ver['gemini'] = !_ver['gemini']!),
          ),
        ],

        if (_modo == 'premium') ...[
          _InfoServicio(
            titulo: 'Premium — OpenAI + Anthropic',
            descripcion:
                'La opción de mayor calidad: Whisper de OpenAI para '
                'transcripción y Claude con búsqueda web para la guía. '
                'Requiere pago en dólares (~\$5/mes para uso estudiantil).\n\n'
                '📌 Claves:\n'
                '• platform.openai.com → API Keys\n'
                '• console.anthropic.com → API Keys',
            color: AppColors.primario,
            icono: Icons.workspace_premium_outlined,
          ),
          const SizedBox(height: 12),
          _CampoApiKey(
            label: 'Clave de OpenAI',
            hint: 'sk-...',
            ctrl: _openAICtrl,
            visible: _ver['openai']!,
            onToggleVer: () =>
                setState(() => _ver['openai'] = !_ver['openai']!),
          ),
          const SizedBox(height: 10),
          _CampoApiKey(
            label: 'Clave de Anthropic (Claude)',
            hint: 'sk-ant-...',
            ctrl: _anthropicCtrl,
            visible: _ver['anthropic']!,
            onToggleVer: () =>
                setState(() => _ver['anthropic'] = !_ver['anthropic']!),
          ),
        ],

        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.primario,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            onPressed: _guardando ? null : _guardar,
            icon: _guardando
                ? const SizedBox(
                    width: 16, height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppColors.texto))
                : const Icon(Icons.save_outlined, size: 18),
            label: Text(_guardando ? 'Guardando...' : 'Guardar configuración'),
          ),
        ),

        const SizedBox(height: 28),
        _EstadoServicios(),
        const SizedBox(height: 24),

        // Acerca de
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.superficie,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Acerca de Apunta',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(
                'Versión 0.1.0\nHecha con ♥️ el Día del Padre 2026\n'
                'Para el futuro de los hijos de Orlando 🙏🏾',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Widgets de apoyo ─────────────────────────────────────────────────────────

class _SelectorModo extends StatelessWidget {
  final String modoActual;
  final ValueChanged<String> onCambiar;

  const _SelectorModo({required this.modoActual, required this.onCambiar});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _TarjetaModo(
          id: 'groq',
          actual: modoActual,
          titulo: '⚡ Gratuito — Solo Groq',
          subtitulo: 'Una cuenta, cero costo. Whisper + Llama 3.3',
          onTap: onCambiar,
        ),
        const SizedBox(height: 8),
        _TarjetaModo(
          id: 'gemini',
          actual: modoActual,
          titulo: '✨ Gratuito — Groq + Gemini',
          subtitulo: 'Transcripción con Groq · Guía con Google Gemini',
          onTap: onCambiar,
        ),
        const SizedBox(height: 8),
        _TarjetaModo(
          id: 'premium',
          actual: modoActual,
          titulo: '🏆 Premium — OpenAI + Claude',
          subtitulo: 'Mayor calidad, con búsqueda web. Requiere pago USD',
          onTap: onCambiar,
        ),
      ],
    );
  }
}

class _TarjetaModo extends StatelessWidget {
  final String id, actual, titulo, subtitulo;
  final ValueChanged<String> onTap;

  const _TarjetaModo({
    required this.id, required this.actual,
    required this.titulo, required this.subtitulo,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final seleccionado = id == actual;
    return GestureDetector(
      onTap: () => onTap(id),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: seleccionado
              ? AppColors.primario.withOpacity(0.12)
              : AppColors.superficie,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: seleccionado ? AppColors.primario : AppColors.borde,
            width: seleccionado ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              seleccionado
                  ? Icons.radio_button_checked
                  : Icons.radio_button_unchecked,
              color: seleccionado ? AppColors.primario : AppColors.textoTerciario,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(titulo,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: seleccionado ? AppColors.texto : AppColors.textoSecundario,
                      )),
                  const SizedBox(height: 2),
                  Text(subtitulo,
                      style: const TextStyle(
                          fontSize: 11, color: AppColors.textoTerciario)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoServicio extends StatelessWidget {
  final String titulo, descripcion;
  final Color color;
  final IconData icono;

  const _InfoServicio({
    required this.titulo, required this.descripcion,
    required this.color, required this.icono,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icono, color: color, size: 16),
              const SizedBox(width: 8),
              Text(titulo,
                  style: TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600, color: color)),
            ],
          ),
          const SizedBox(height: 8),
          Text(descripcion,
              style: const TextStyle(
                  fontSize: 12, color: AppColors.textoSecundario, height: 1.5)),
        ],
      ),
    );
  }
}

class _CampoApiKey extends StatelessWidget {
  final String label, hint;
  final TextEditingController ctrl;
  final bool visible;
  final VoidCallback onToggleVer;

  const _CampoApiKey({
    required this.label, required this.hint,
    required this.ctrl, required this.visible,
    required this.onToggleVer,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: ctrl,
      obscureText: !visible,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: AppColors.superficie,
        suffixIcon: IconButton(
          icon: Icon(visible ? Icons.visibility_off : Icons.visibility, size: 18),
          onPressed: onToggleVer,
        ),
      ),
    );
  }
}

class _EstadoServicios extends StatelessWidget {
  const _EstadoServicios();

  @override
  Widget build(BuildContext context) {
    final transcOk = TranscriptionService.instancia.estaConfigurado;
    final iaOk     = AIService.instancia.estaConfigurado;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.superficie,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Estado', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          _Fila(label: 'Transcripción de audio', activo: transcOk),
          const SizedBox(height: 6),
          _Fila(label: 'Generación de guía de estudio', activo: iaOk),
        ],
      ),
    );
  }
}

class _Fila extends StatelessWidget {
  final String label;
  final bool activo;
  const _Fila({required this.label, required this.activo});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          activo ? Icons.check_circle_outline : Icons.radio_button_unchecked,
          size: 16,
          color: activo ? AppColors.secundario : AppColors.textoTerciario,
        ),
        const SizedBox(width: 8),
        Text(label,
            style: TextStyle(
                fontSize: 13,
                color: activo ? AppColors.texto : AppColors.textoTerciario)),
      ],
    );
  }
}
