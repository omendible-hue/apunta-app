import 'package:flutter/material.dart';
import '../models/clase.dart';
import '../theme/app_theme.dart';

/// Chip visual que representa el estado de procesamiento de una clase grabada.
class EstadoChip extends StatelessWidget {
  final EstadoClase estado;
  const EstadoChip({super.key, required this.estado});

  @override
  Widget build(BuildContext context) {
    final (label, color, icono) = switch (estado) {
      EstadoClase.grabando      => ('Grabando',       AppColors.grabando,   Icons.mic),
      EstadoClase.grabada       => ('Pendiente wifi', AppColors.textoSecundario, Icons.cloud_upload_outlined),
      EstadoClase.sincronizando => ('Subiendo...',    AppColors.primario,   Icons.sync),
      EstadoClase.transcribiendo=> ('Procesando...',  AppColors.primario,   Icons.auto_awesome),
      EstadoClase.lista         => ('Guía lista',     AppColors.secundario, Icons.check_circle_outline),
      EstadoClase.error         => ('Error',          AppColors.detener,    Icons.error_outline),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icono, size: 11, color: color),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  fontSize: 11, color: color, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
