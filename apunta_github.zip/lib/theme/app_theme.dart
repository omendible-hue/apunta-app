import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Identidad visual de "Apunta".
/// Fondo azul-violeta profundo (no negro puro), violeta eléctrico como
/// primario, verde-azulado para estados "listo", ámbar cálido para la
/// grabación activa. Ver conversación de diseño para el razonamiento
/// completo detrás de esta paleta.
class AppColors {
  static const fondo = Color(0xFF15132B);
  static const superficie = Color(0xFF211D3D);
  static const superficieAlt = Color(0xFF1B1836);
  static const borde = Color(0xFF332D5C);

  static const primario = Color(0xFF6C5CE7); // violeta eléctrico
  static const secundario = Color(0xFF00D9B5); // verde-azulado, "listo"
  static const grabando = Color(0xFFFFB648); // ámbar, grabación activa
  static const detener = Color(0xFFE24B4A); // rojo, solo para detener

  static const texto = Color(0xFFF2F0FA);
  static const textoSecundario = Color(0xFF9C97C4);
  static const textoTerciario = Color(0xFF7A75A3);
}

class AppTheme {
  static ThemeData get tema {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.fondo,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primario,
        secondary: AppColors.secundario,
        surface: AppColors.superficie,
        error: AppColors.detener,
        onPrimary: AppColors.texto,
        onSurface: AppColors.texto,
      ),
      textTheme: _construirTextTheme(base.textTheme),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.fondo,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      cardTheme: CardThemeData(
        color: AppColors.superficieAlt,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.superficieAlt,
        elevation: 0,
        indicatorColor: AppColors.primario.withOpacity(0.2),
        labelTextStyle: WidgetStateProperty.all(
          GoogleFonts.inter(fontSize: 11, color: AppColors.textoSecundario),
        ),
      ),
    );
  }

  static TextTheme _construirTextTheme(TextTheme base) {
    // Space Grotesk para títulos (carácter, geometría moderna),
    // Inter para texto de cuerpo (legibilidad en pantallas chicas).
    return GoogleFonts.interTextTheme(base).copyWith(
      headlineMedium: GoogleFonts.spaceGrotesk(
        fontSize: 24,
        fontWeight: FontWeight.w600,
        color: AppColors.texto,
      ),
      headlineSmall: GoogleFonts.spaceGrotesk(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        color: AppColors.texto,
      ),
      titleMedium: GoogleFonts.spaceGrotesk(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: AppColors.texto,
      ),
      bodyMedium: GoogleFonts.inter(
        fontSize: 14,
        color: AppColors.texto,
      ),
      bodySmall: GoogleFonts.inter(
        fontSize: 12,
        color: AppColors.textoSecundario,
      ),
    );
  }
}

/// Fuente monoespaciada para duraciones y timestamps de grabación
/// (JetBrains Mono vía Google Fonts).
TextStyle textoMono({double size = 14, Color? color}) =>
    GoogleFonts.jetBrainsMono(
      fontSize: size,
      color: color ?? AppColors.texto,
      fontWeight: FontWeight.w500,
    );
