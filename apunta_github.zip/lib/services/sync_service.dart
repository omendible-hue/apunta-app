import 'package:connectivity_plus/connectivity_plus.dart';
import '../models/clase.dart';
import '../services/db_service.dart';
import '../services/transcription_service.dart';
import '../services/ai_service.dart';

/// Orquesta el flujo completo de procesamiento de una clase grabada:
/// 1. Detecta que hay wifi disponible.
/// 2. Busca clases en estado `grabada` (audio listo, sin transcripción).
/// 3. Transcribe el audio con Whisper.
/// 4. Genera guía de estudio y ejercicios con Claude.
/// 5. Actualiza el estado en la base de datos local.
///
/// Diseñado para correr de forma transparente — el estudiante no tiene
/// que hacer nada más que conectarse al wifi después de clase.
class SyncService {
  SyncService._();
  static final SyncService instancia = SyncService._();

  bool _procesando = false;

  /// Callback opcional para notificar a la UI del progreso.
  void Function(String claseId, EstadoClase estado)? onEstadoCambiado;

  /// Inicia la escucha de conectividad. Cuando aparece wifi, procesa la cola.
  /// Llamar una sola vez al iniciar la app (en main.dart).
  void iniciarEscucha() {
    Connectivity().onConnectivityChanged.listen((results) {
      final tieneWifi = results.any((r) =>
          r == ConnectivityResult.wifi || r == ConnectivityResult.ethernet);
      if (tieneWifi) {
        procesarCola();
      }
    });
  }

  /// Procesa manualmente la cola (útil para el botón "Reintentar" en la UI).
  Future<void> procesarCola() async {
    if (_procesando) return;
    _procesando = true;

    try {
      final db = DBService.instancia;
      final todasLasClases = await db.listarClases();

      // Filtramos las que tienen audio local pero aún no se transcribieron
      final pendientes = todasLasClases.where((c) =>
          c.estado == EstadoClase.grabada &&
          c.rutaAudio != null).toList();

      for (final clase in pendientes) {
        await _procesarClase(clase);
      }
    } finally {
      _procesando = false;
    }
  }

  Future<void> _procesarClase(Clase clase) async {
    final db = DBService.instancia;

    // Necesitamos la materia para dar contexto a la IA
    final materias = await db.listarMaterias();
    final materia = materias.where((m) => m.id == clase.materiaId).firstOrNull;
    final nombreMateria = materia?.nombre ?? 'clase';

    try {
      // --- Fase 1: Transcripción ---
      await _actualizarEstado(db, clase, EstadoClase.sincronizando);

      if (!TranscriptionService.instancia.estaConfigurado) {
        // Sin API key de Whisper no podemos continuar —
        // dejamos la clase en `grabada` para reintentar luego.
        await _actualizarEstado(db, clase, EstadoClase.grabada);
        return;
      }

      await _actualizarEstado(db, clase, EstadoClase.transcribiendo);
      final transcripcion = await TranscriptionService.instancia
          .transcribir(clase.rutaAudio!);

      // Guardamos la transcripción aunque la IA falle después
      Clase claseActual = clase.copyWith(
        estado: EstadoClase.transcribiendo,
        transcripcion: transcripcion,
      );
      await db.guardarClase(claseActual);

      // --- Fase 2: Guía de estudio + Ejercicios con Claude ---
      if (!AIService.instancia.estaConfigurado) {
        await _actualizarEstado(db, claseActual, EstadoClase.grabada);
        return;
      }

      final resultado = await AIService.instancia.procesarTranscripcion(
        transcripcion: transcripcion,
        materia: nombreMateria,
        fecha: clase.fecha,
      );

      // --- Éxito: guardamos todo y marcamos como lista ---
      final claseCompleta = claseActual.copyWith(
        estado: EstadoClase.lista,
        guiaEstudio: resultado.guiaEstudio,
        ejercicios: resultado.ejercicios,
      );
      await db.guardarClase(claseCompleta);
      onEstadoCambiado?.call(clase.id, EstadoClase.lista);
    } catch (e) {
      // Guardamos el error pero no bloqueamos el resto de la cola
      final claseError = clase.copyWith(estado: EstadoClase.error);
      await db.guardarClase(claseError);
      onEstadoCambiado?.call(clase.id, EstadoClase.error);
    }
  }

  Future<void> _actualizarEstado(
      DBService db, Clase clase, EstadoClase estado) async {
    final actualizada = clase.copyWith(estado: estado);
    await db.guardarClase(actualizada);
    onEstadoCambiado?.call(clase.id, estado);
  }
}
