import 'dart:convert';
import 'package:http/http.dart' as http;

enum ProveedorIA { anthropic, groq, gemini }

/// Resultado del procesamiento de IA para una clase.
class ResultadoIA {
  final String guiaEstudio;
  final String ejercicios;
  const ResultadoIA({required this.guiaEstudio, required this.ejercicios});
}

/// Genera guía de estudio y ejercicios a partir de una transcripción.
/// Soporta tres proveedores intercambiables:
///
/// - **Groq** (gratuito): Llama 3.3 70B — excelente calidad, sin costo,
///   solo requiere cuenta en console.groq.com con email.
/// - **Gemini** (gratuito): Gemini 2.0 Flash — muy capaz, capa gratuita
///   generosa, cuenta Google sin tarjeta de crédito.
/// - **Anthropic** (pago): Claude — la opción premium con búsqueda web.
class AIService {
  AIService._();
  static final AIService instancia = AIService._();

  String? _apiKey;
  ProveedorIA _proveedor = ProveedorIA.groq;

  void configurar({
    required String apiKey,
    ProveedorIA proveedor = ProveedorIA.groq,
  }) {
    _apiKey = apiKey;
    _proveedor = proveedor;
  }

  bool get estaConfigurado => _apiKey != null && _apiKey!.isNotEmpty;
  ProveedorIA get proveedor => _proveedor;

  Future<ResultadoIA> procesarTranscripcion({
    required String transcripcion,
    required String materia,
    required DateTime fecha,
  }) async {
    if (!estaConfigurado) {
      throw AIException('API key no configurada. Ve a Ajustes.');
    }

    final guia = await _generarGuia(
        transcripcion: transcripcion, materia: materia, fecha: fecha);
    final ejercicios = await _generarEjercicios(guia: guia, materia: materia);
    return ResultadoIA(guiaEstudio: guia, ejercicios: ejercicios);
  }

  // ─── Prompts (iguales para todos los proveedores) ───────────────────────

  String _promptGuia(String transcripcion, String materia, DateTime fecha) => '''
Eres un asistente de estudio para estudiantes. Se te proporciona la transcripción de una clase de **$materia** del ${_formatFecha(fecha)}.

Convierte la transcripción en una **guía de estudio clara y bien estructurada** en español.

TRANSCRIPCIÓN:
---
$transcripcion
---

INSTRUCCIONES:
1. Identifica el tema central de la clase.
2. Organiza los conceptos con títulos (## para secciones).
3. Para cada concepto: explícalo, define precisamente y da un ejemplo.
4. Si hay fórmulas o pasos, preséntalos claramente.
5. Añade una sección "💡 Puntos clave" al final con los 3-5 más importantes.
6. Complementa con información precisa adicional cuando sea útil bajo "📚 Para profundizar".
7. Usa **negrita** para términos técnicos.
8. Tono cercano y motivador para estudiantes jóvenes.

Responde SOLO con la guía en Markdown.
''';

  String _promptEjercicios(String guia, String materia) => '''
Basándote en esta guía de $materia, crea material de práctica.

GUÍA:
---
$guia
---

Crea DOS secciones en Markdown:

## 📝 Ejercicios prácticos
4-5 ejercicios variados en dificultad. Después de cada uno: "**Pista:** [pista breve]".

## ✅ Quiz rápido
5 preguntas de selección múltiple (A, B, C, D). Marca la correcta: *(Respuesta: X)*.

Responde SOLO con el Markdown.
''';

  // ─── Enrutador por proveedor ─────────────────────────────────────────────

  Future<String> _generarGuia({
    required String transcripcion,
    required String materia,
    required DateTime fecha,
  }) async {
    final prompt = _promptGuia(transcripcion, materia, fecha);
    return switch (_proveedor) {
      ProveedorIA.anthropic => await _llamarClaude(prompt, maxTokens: 2000),
      ProveedorIA.groq      => await _llamarGroq(prompt, maxTokens: 2000),
      ProveedorIA.gemini    => await _llamarGemini(prompt, maxTokens: 2000),
    };
  }

  Future<String> _generarEjercicios({
    required String guia,
    required String materia,
  }) async {
    final prompt = _promptEjercicios(guia, materia);
    return switch (_proveedor) {
      ProveedorIA.anthropic => await _llamarClaude(prompt, maxTokens: 1500),
      ProveedorIA.groq      => await _llamarGroq(prompt, maxTokens: 1500),
      ProveedorIA.gemini    => await _llamarGemini(prompt, maxTokens: 1500),
    };
  }

  // ─── Claude (Anthropic) ──────────────────────────────────────────────────

  Future<String> _llamarClaude(String prompt, {required int maxTokens}) async {
    final respuesta = await http.post(
      Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey!,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': 'claude-sonnet-4-6',
        'max_tokens': maxTokens,
        'tools': [{'type': 'web_search_20250305', 'name': 'web_search'}],
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      }),
    );
    return _extraerTexto(respuesta, 'Anthropic');
  }

  // ─── Groq (Llama 3.3 70B — gratuito) ────────────────────────────────────

  Future<String> _llamarGroq(String prompt, {required int maxTokens}) async {
    final respuesta = await http.post(
      Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_apiKey',
      },
      body: jsonEncode({
        'model': 'llama-3.3-70b-versatile',
        'max_tokens': maxTokens,
        'messages': [
          {
            'role': 'system',
            'content':
                'Eres un asistente de estudio experto. Respondes siempre '
                'en español y en formato Markdown limpio.'
          },
          {'role': 'user', 'content': prompt},
        ],
      }),
    );

    if (respuesta.statusCode != 200) {
      final e = jsonDecode(respuesta.body);
      throw AIException(
          'Error Groq (${respuesta.statusCode}): '
          '${e['error']?['message'] ?? respuesta.body}');
    }

    final json = jsonDecode(respuesta.body);
    return (json['choices'][0]['message']['content'] as String).trim();
  }

  // ─── Gemini (Google — gratuito) ──────────────────────────────────────────

  Future<String> _llamarGemini(String prompt, {required int maxTokens}) async {
    final url =
        'https://generativelanguage.googleapis.com/v1beta/models/'
        'gemini-2.0-flash-exp:generateContent?key=$_apiKey';

    final respuesta = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {
                'text':
                    'Eres un asistente de estudio experto. Responde en español '
                    'y en Markdown limpio.\n\n$prompt'
              }
            ]
          }
        ],
        'generationConfig': {'maxOutputTokens': maxTokens},
      }),
    );

    if (respuesta.statusCode != 200) {
      final e = jsonDecode(respuesta.body);
      throw AIException(
          'Error Gemini (${respuesta.statusCode}): '
          '${e['error']?['message'] ?? respuesta.body}');
    }

    final json = jsonDecode(respuesta.body);
    return (json['candidates'][0]['content']['parts'][0]['text'] as String)
        .trim();
  }

  // ─── Helper ──────────────────────────────────────────────────────────────

  String _extraerTexto(http.Response respuesta, String proveedor) {
    if (respuesta.statusCode != 200) {
      final e = jsonDecode(respuesta.body);
      throw AIException(
          'Error $proveedor (${respuesta.statusCode}): '
          '${e['error']?['message'] ?? respuesta.body}');
    }
    final json = jsonDecode(respuesta.body) as Map<String, dynamic>;
    final content = json['content'] as List;
    final texto = content
        .where((b) => b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join('\n')
        .trim();
    if (texto.isEmpty) throw AIException('El modelo no devolvió texto.');
    return texto;
  }

  String _formatFecha(DateTime f) {
    const meses = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
      'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    return '${f.day} de ${meses[f.month - 1]} de ${f.year}';
  }
}

class AIException implements Exception {
  final String mensaje;
  const AIException(this.mensaje);
  @override
  String toString() => 'AIException: $mensaje';
}


/// Usa Claude para convertir una transcripción de clase en:
/// 1. Una guía de estudio estructurada (resumen, conceptos clave, ejemplos)
/// 2. Ejercicios prácticos y un quiz corto de comprensión
///
/// Claude tiene acceso a búsqueda web para complementar lo que el profesor
/// dijo con fuentes adicionales (definiciones precisas, fórmulas, contexto).
class AIService {
  AIService._();
  static final AIService instancia = AIService._();

  static const _apiUrl = 'https://api.anthropic.com/v1/messages';
  static const _modelo = 'claude-sonnet-4-6';

  String? _apiKey;

  void configurar({required String anthropicKey}) {
    _apiKey = anthropicKey;
  }

  bool get estaConfigurado => _apiKey != null && _apiKey!.isNotEmpty;

  /// Genera la guía de estudio y los ejercicios a partir de la transcripción.
  /// `materia` y `fecha` sirven de contexto para que Claude entienda el tema.
  Future<ResultadoIA> procesarTranscripcion({
    required String transcripcion,
    required String materia,
    required DateTime fecha,
  }) async {
    if (!estaConfigurado) {
      throw AIException(
          'API key de Anthropic no configurada. Ve a Ajustes para agregarla.');
    }

    // Paso 1: Guía de estudio con búsqueda web integrada
    final guia = await _generarGuia(
      transcripcion: transcripcion,
      materia: materia,
      fecha: fecha,
    );

    // Paso 2: Ejercicios y quiz basados en la guía ya generada
    final ejercicios = await _generarEjercicios(
      guia: guia,
      materia: materia,
    );

    return ResultadoIA(guiaEstudio: guia, ejercicios: ejercicios);
  }

  Future<String> _generarGuia({
    required String transcripcion,
    required String materia,
    required DateTime fecha,
  }) async {
    final prompt = '''
Eres un asistente de estudio para estudiantes de secundaria y universidad.
Se te proporciona la transcripción de una clase de **$materia** del ${_formatFecha(fecha)}.

Tu tarea es convertirla en una **guía de estudio clara y bien estructurada** en español.

TRANSCRIPCIÓN DE LA CLASE:
---
$transcripcion
---

INSTRUCCIONES:
1. Identifica el tema central de la clase.
2. Organiza los conceptos en secciones con títulos claros (usa ## para secciones).
3. Para cada concepto importante: explícalo con tus propias palabras, añade una definición precisa, y da un ejemplo concreto si aplica.
4. Si hay fórmulas, procesos o pasos, preséntalos claramente.
5. Añade una sección "💡 Puntos clave" al final con los 3-5 conceptos más importantes.
6. Si la transcripción menciona temas que puedes complementar con información adicional precisa (definiciones, fórmulas exactas, contexto histórico), agrégalo como "📚 Para profundizar".
7. Usa **negrita** para términos técnicos importantes.
8. El tono debe ser cercano y motivador para estudiantes jóvenes.

Responde SOLO con la guía en Markdown, sin explicaciones adicionales.
''';

    return await _llamarClaude(
      prompt: prompt,
      usarBusqueda: true, // Claude busca en web para complementar
      maxTokens: 2000,
    );
  }

  Future<String> _generarEjercicios({
    required String guia,
    required String materia,
  }) async {
    final prompt = '''
Eres un asistente de estudio. Basándote en esta guía de $materia, crea material de práctica para el estudiante.

GUÍA DE ESTUDIO:
---
$guia
---

Crea DOS secciones en Markdown:

## 📝 Ejercicios prácticos
Genera 4-5 ejercicios o problemas aplicados sobre los temas de la guía.
- Varía la dificultad (fáciles, medios, uno desafiante).
- Para materias de ciencias: incluye problemas numéricos si aplica.
- Para materias humanísticas: incluye preguntas de análisis y reflexión.
- Después de cada ejercicio, agrega una línea en blanco y escribe "**Pista:** [una pista breve sin revelar la respuesta completa]".

## ✅ Quiz rápido
Genera 5 preguntas de selección múltiple con 4 opciones cada una (A, B, C, D).
Marca la respuesta correcta al final de cada pregunta así: *(Respuesta: X)*.

El tono debe ser retador pero motivador. Responde SOLO con el Markdown, sin explicaciones adicionales.
''';

    return await _llamarClaude(
      prompt: prompt,
      usarBusqueda: false,
      maxTokens: 1500,
    );
  }

  /// Llama a la API de Claude con o sin búsqueda web.
  Future<String> _llamarClaude({
    required String prompt,
    required bool usarBusqueda,
    required int maxTokens,
  }) async {
    final body = <String, dynamic>{
      'model': _modelo,
      'max_tokens': maxTokens,
      'messages': [
        {'role': 'user', 'content': prompt},
      ],
    };

    if (usarBusqueda) {
      body['tools'] = [
        {
          'type': 'web_search_20250305',
          'name': 'web_search',
        }
      ];
    }

    final respuesta = await http.post(
      Uri.parse(_apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey!,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode(body),
    );

    if (respuesta.statusCode != 200) {
      final error = jsonDecode(respuesta.body);
      throw AIException(
          'Error de Claude API (${respuesta.statusCode}): '
          '${error['error']?['message'] ?? respuesta.body}');
    }

    final json = jsonDecode(respuesta.body) as Map<String, dynamic>;
    final content = json['content'] as List;

    // Extraemos solo los bloques de texto (ignoramos tool_use y tool_result)
    final texto = content
        .where((b) => b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join('\n')
        .trim();

    if (texto.isEmpty) {
      throw AIException('Claude no devolvió texto en la respuesta.');
    }

    return texto;
  }

  String _formatFecha(DateTime f) {
    const meses = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
      'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    return '${f.day} de ${meses[f.month - 1]} de ${f.year}';
  }
}

class AIException implements Exception {
  final String mensaje;
  const AIException(this.mensaje);

  @override
  String toString() => 'AIException: $mensaje';
}
