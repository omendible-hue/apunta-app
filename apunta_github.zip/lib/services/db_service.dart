import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/materia.dart';
import '../models/horario.dart';
import '../models/clase.dart';

/// Capa única de acceso a la base de datos local (SQLite).
/// Todo lo que no requiere internet —materias, horario, recordatorios,
/// metadatos de clases grabadas— vive aquí, disponible offline siempre.
class DBService {
  DBService._();
  static final DBService instancia = DBService._();

  Database? _db;

  Future<Database> get db async {
    _db ??= await _inicializar();
    return _db!;
  }

  Future<Database> _inicializar() async {
    final ruta = join(await getDatabasesPath(), 'apunta.db');
    return openDatabase(
      ruta,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE materias (
            id TEXT PRIMARY KEY,
            nombre TEXT NOT NULL,
            colorHex INTEGER NOT NULL,
            profesor TEXT,
            aula TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE bloques_horario (
            id TEXT PRIMARY KEY,
            materiaId TEXT NOT NULL,
            diaSemana INTEGER NOT NULL,
            horaInicio INTEGER NOT NULL,
            horaFin INTEGER NOT NULL,
            notificarInicio INTEGER NOT NULL,
            minutosAntes INTEGER NOT NULL,
            FOREIGN KEY (materiaId) REFERENCES materias (id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''
          CREATE TABLE recordatorios (
            id TEXT PRIMARY KEY,
            materiaId TEXT,
            titulo TEXT NOT NULL,
            fechaHora TEXT NOT NULL,
            tipo TEXT NOT NULL,
            notas TEXT,
            FOREIGN KEY (materiaId) REFERENCES materias (id) ON DELETE SET NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE clases (
            id TEXT PRIMARY KEY,
            materiaId TEXT NOT NULL,
            fecha TEXT NOT NULL,
            rutaAudio TEXT,
            duracionSegundos INTEGER,
            rutasFotos TEXT,
            estado TEXT NOT NULL,
            transcripcion TEXT,
            guiaEstudio TEXT,
            ejercicios TEXT,
            FOREIGN KEY (materiaId) REFERENCES materias (id) ON DELETE CASCADE
          )
        ''');
      },
    );
  }

  // ---------- Materias ----------

  Future<void> guardarMateria(Materia m) async {
    final database = await db;
    await database.insert('materias', m.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Materia>> listarMaterias() async {
    final database = await db;
    final filas = await database.query('materias', orderBy: 'nombre');
    return filas.map(Materia.fromMap).toList();
  }

  Future<void> eliminarMateria(String id) async {
    final database = await db;
    await database.delete('materias', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Bloques de horario ----------

  Future<void> guardarBloque(BloqueHorario b) async {
    final database = await db;
    await database.insert('bloques_horario', b.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<BloqueHorario>> listarBloques() async {
    final database = await db;
    final filas = await database.query('bloques_horario',
        orderBy: 'diaSemana, horaInicio');
    return filas.map(BloqueHorario.fromMap).toList();
  }

  Future<void> eliminarBloque(String id) async {
    final database = await db;
    await database.delete('bloques_horario', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Recordatorios ----------

  Future<void> guardarRecordatorio(Recordatorio r) async {
    final database = await db;
    await database.insert('recordatorios', r.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Recordatorio>> listarRecordatorios() async {
    final database = await db;
    final filas = await database.query('recordatorios', orderBy: 'fechaHora');
    return filas.map(Recordatorio.fromMap).toList();
  }

  Future<void> eliminarRecordatorio(String id) async {
    final database = await db;
    await database.delete('recordatorios', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Clases ----------

  Future<void> guardarClase(Clase c) async {
    final database = await db;
    await database.insert('clases', c.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Clase>> listarClases({String? materiaId}) async {
    final database = await db;
    final filas = await database.query(
      'clases',
      where: materiaId != null ? 'materiaId = ?' : null,
      whereArgs: materiaId != null ? [materiaId] : null,
      orderBy: 'fecha DESC',
    );
    return filas.map(Clase.fromMap).toList();
  }
}
