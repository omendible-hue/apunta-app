import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

/// Puente hacia el servicio nativo de grabación (RecordingService.kt).
/// La UI Flutter solo llama a estos dos métodos; toda la complejidad de
/// foreground service, notificación silenciosa y MediaRecorder vive en Kotlin.
class RecordingService {
  static const _channel = MethodChannel('com.orlando.classtracker/recording');

  /// Pide permiso de micrófono si hace falta y arranca la grabación.
  /// Devuelve false si el permiso fue denegado.
  static Future<bool> iniciar(String materiaNombre) async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) return false;

    // En Android 13+ también conviene pedir el permiso de notificaciones,
    // porque el foreground service necesita mostrar una.
    if (await Permission.notification.isDenied) {
      await Permission.notification.request();
    }

    await _channel.invokeMethod('startRecording', {
      'materiaNombre': materiaNombre,
    });
    return true;
  }

  static Future<void> detener() async {
    await _channel.invokeMethod('stopRecording');
  }
}
