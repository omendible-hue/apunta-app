import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import '../models/clase.dart';
import '../models/materia.dart';

/// Genera un PDF completo de una clase —guía de estudio, ejercicios y
/// fotos del pizarrón— y lo pone disponible para compartir via el menú
/// nativo de Android (WhatsApp, Drive, correo, Telegram, etc.).
///
/// El PDF usa la paleta de Apunta: fondo oscuro para portada,
/// tipografía clara para el contenido. Compatible con cualquier visor.
class ExportService {
  ExportService._();
  static final ExportService instancia = ExportService._();

  /// Genera el PDF y abre el menú de compartir de Android.
  /// Devuelve la ruta del archivo generado (útil para "Abrir" desde la UI).
  Future<String> exportarYCompartir({
    required Clase clase,
    required Materia? materia,
  }) async {
    final pdf = pw.Document(
      author: 'Apunta',
      title: _tituloDoc(clase, materia),
    );

    // ── Portada ──────────────────────────────────────────────────────────
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (ctx) => _portada(ctx, clase, materia),
      ),
    );

    // ── Guía de estudio ──────────────────────────────────────────────────
    if (clase.guiaEstudio != null && clase.guiaEstudio!.isNotEmpty) {
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.symmetric(horizontal: 40, vertical: 36),
          header: (_) => _encabezadoPagina('📚 Guía de estudio', materia),
          footer: (ctx) => _piePagina(ctx),
          build: (ctx) => _renderizarMarkdown(clase.guiaEstudio!),
        ),
      );
    }

    // ── Ejercicios y quiz ────────────────────────────────────────────────
    if (clase.ejercicios != null && clase.ejercicios!.isNotEmpty) {
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.symmetric(horizontal: 40, vertical: 36),
          header: (_) => _encabezadoPagina('📝 Ejercicios y quiz', materia),
          footer: (ctx) => _piePagina(ctx),
          build: (ctx) => _renderizarMarkdown(clase.ejercicios!),
        ),
      );
    }

    // ── Fotos del pizarrón ───────────────────────────────────────────────
    final fotosValidas = <String>[];
    for (final ruta in clase.rutasFotos) {
      if (await File(ruta).exists()) fotosValidas.add(ruta);
    }

    if (fotosValidas.isNotEmpty) {
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.symmetric(horizontal: 40, vertical: 36),
          header: (_) => _encabezadoPagina('📷 Fotos del pizarrón', materia),
          footer: (ctx) => _piePagina(ctx),
          build: (ctx) => _gridFotos(fotosValidas),
        ),
      );
    }

    // ── Guardar y compartir ──────────────────────────────────────────────
    final dir = await getApplicationDocumentsDirectory();
    final exportDir = Directory(p.join(dir.path, 'exportados'));
    await exportDir.create(recursive: true);

    final nombreArchivo =
        '${materia?.nombre.replaceAll(' ', '_') ?? 'Apuntes'}'
        '_${_fechaCorta(clase.fecha)}.pdf';
    final rutaArchivo = p.join(exportDir.path, nombreArchivo);

    final bytes = await pdf.save();
    await File(rutaArchivo).writeAsBytes(bytes);

    // Abrir el menú nativo de compartir de Android
    await Share.shareXFiles(
      [XFile(rutaArchivo)],
      subject: _tituloDoc(clase, materia),
      text:
          'Apuntes de ${materia?.nombre ?? 'clase'} '
          '— ${_fechaLarga(clase.fecha)}\n'
          'Generados con Apunta 🙏🏾',
    );

    return rutaArchivo;
  }

  // ─── Bloques del PDF ───────────────────────────────────────────────────

  pw.Widget _portada(pw.Context ctx, Clase clase, Materia? materia) {
    final colorMateria = materia != null
        ? PdfColor.fromInt(materia.colorHex)
        : const PdfColor.fromInt(0xFF6C5CE7);

    return pw.Container(
      color: const PdfColor.fromInt(0xFF15132B),
      padding: const pw.EdgeInsets.all(48),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Spacer(),
          // Barra de color de la materia
          pw.Container(
            width: 48,
            height: 4,
            color: colorMateria,
          ),
          pw.SizedBox(height: 24),
          pw.Text(
            materia?.nombre ?? 'Apuntes',
            style: pw.TextStyle(
              fontSize: 32,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.white,
            ),
          ),
          pw.SizedBox(height: 12),
          pw.Text(
            _fechaLarga(clase.fecha),
            style: const pw.TextStyle(
              fontSize: 14,
              color: PdfColor.fromInt(0xFF9C97C4),
            ),
          ),
          if (materia?.profesor != null) ...[
            pw.SizedBox(height: 6),
            pw.Text(
              'Prof. ${materia!.profesor}',
              style: const pw.TextStyle(
                fontSize: 13,
                color: PdfColor.fromInt(0xFF9C97C4),
              ),
            ),
          ],
          pw.Spacer(),
          pw.Divider(color: const PdfColor.fromInt(0xFF332D5C)),
          pw.SizedBox(height: 12),
          pw.Text(
            'Generado con Apunta · ${_fechaCorta(clase.fecha)}',
            style: const pw.TextStyle(
              fontSize: 10,
              color: PdfColor.fromInt(0xFF7A75A3),
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _encabezadoPagina(String titulo, Materia? materia) {
    final colorMateria = materia != null
        ? PdfColor.fromInt(materia.colorHex)
        : const PdfColor.fromInt(0xFF6C5CE7);
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              titulo,
              style: pw.TextStyle(
                  fontSize: 13,
                  fontWeight: pw.FontWeight.bold,
                  color: colorMateria),
            ),
            pw.Text(
              materia?.nombre ?? '',
              style: const pw.TextStyle(
                  fontSize: 11, color: PdfColor.fromInt(0xFF9C97C4)),
            ),
          ],
        ),
        pw.SizedBox(height: 4),
        pw.Divider(color: const PdfColor.fromInt(0xFF332D5C)),
        pw.SizedBox(height: 8),
      ],
    );
  }

  pw.Widget _piePagina(pw.Context ctx) {
    return pw.Column(
      children: [
        pw.Divider(color: const PdfColor.fromInt(0xFF332D5C)),
        pw.SizedBox(height: 4),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Apunta',
                style: const pw.TextStyle(
                    fontSize: 9, color: PdfColor.fromInt(0xFF7A75A3))),
            pw.Text('Página ${ctx.pageNumber} de ${ctx.pagesCount}',
                style: const pw.TextStyle(
                    fontSize: 9, color: PdfColor.fromInt(0xFF7A75A3))),
          ],
        ),
      ],
    );
  }

  /// Renderiza el Markdown básico que genera la IA: ## títulos y **negrita**.
  List<pw.Widget> _renderizarMarkdown(String markdown) {
    final widgets = <pw.Widget>[];
    for (final linea in markdown.split('\n')) {
      if (linea.startsWith('## ')) {
        widgets.add(pw.SizedBox(height: 14));
        widgets.add(pw.Text(
          linea.substring(3),
          style: pw.TextStyle(
            fontSize: 14,
            fontWeight: pw.FontWeight.bold,
            color: const PdfColor.fromInt(0xFF6C5CE7),
          ),
        ));
        widgets.add(pw.SizedBox(height: 4));
      } else if (linea.startsWith('# ')) {
        widgets.add(pw.SizedBox(height: 18));
        widgets.add(pw.Text(
          linea.substring(2),
          style: pw.TextStyle(
            fontSize: 18,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.white,
          ),
        ));
        widgets.add(pw.SizedBox(height: 6));
      } else if (linea.trim().isEmpty) {
        widgets.add(pw.SizedBox(height: 8));
      } else {
        // Negrita simple: texto normal con negritas intercaladas
        final partes = linea.split('**');
        final spans = <pw.TextSpan>[];
        for (var i = 0; i < partes.length; i++) {
          if (partes[i].isEmpty) continue;
          spans.add(pw.TextSpan(
            text: partes[i],
            style: pw.TextStyle(
              fontSize: 11,
              fontWeight:
                  i.isOdd ? pw.FontWeight.bold : pw.FontWeight.normal,
              color: i.isOdd
                  ? PdfColors.white
                  : const PdfColor.fromInt(0xFFCCCCDD),
            ),
          ));
        }
        widgets.add(pw.RichText(text: pw.TextSpan(children: spans)));
        widgets.add(pw.SizedBox(height: 3));
      }
    }
    return widgets;
  }

  /// Grilla de fotos del pizarrón: 2 columnas, con borde redondeado.
  List<pw.Widget> _gridFotos(List<String> rutas) {
    final widgets = <pw.Widget>[];
    for (var i = 0; i < rutas.length; i += 2) {
      final fila = <pw.Widget>[
        _celdaFoto(rutas[i], i + 1),
        pw.SizedBox(width: 12),
        if (i + 1 < rutas.length)
          _celdaFoto(rutas[i + 1], i + 2)
        else
          pw.Expanded(child: pw.SizedBox()),
      ];
      widgets.add(pw.Row(children: fila));
      widgets.add(pw.SizedBox(height: 12));
    }
    return widgets;
  }

  pw.Widget _celdaFoto(String ruta, int numero) {
    final bytes = File(ruta).readAsBytesSync();
    return pw.Expanded(
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.ClipRRect(
            horizontalRadius: 6,
            verticalRadius: 6,
            child: pw.Image(
              pw.MemoryImage(bytes),
              fit: pw.BoxFit.contain,
            ),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            'Foto $numero',
            style: const pw.TextStyle(
                fontSize: 9, color: PdfColor.fromInt(0xFF9C97C4)),
          ),
        ],
      ),
    );
  }

  // ─── Helpers ──────────────────────────────────────────────────────────

  String _tituloDoc(Clase clase, Materia? materia) {
    return 'Apuntes ${materia?.nombre ?? ''} — ${_fechaCorta(clase.fecha)}';
  }

  String _fechaCorta(DateTime f) =>
      '${f.day.toString().padLeft(2, '0')}-'
      '${f.month.toString().padLeft(2, '0')}-${f.year}';

  String _fechaLarga(DateTime f) {
    const meses = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
      'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    return '${f.day} de ${meses[f.month - 1]} de ${f.year}';
  }
}
