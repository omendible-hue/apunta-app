import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;
import '../models/horario.dart';
import '../models/materia.dart';

/// Centraliza toda la programación de notificaciones locales:
/// - Bloques de horario: notificación semanal recurrente N minutos antes
///   de que inicie la clase (usa `matchDateTimeComponents` para repetir
///   cada semana sin tener que reprogramar manualmente).
/// - Recordatorios: notificación puntual única en la fecha/hora exacta
///   (pruebas, entregas, fechas importantes).
///
/// IDs de notificación: para que sean estables y se puedan cancelar/
/// reemplazar, derivamos un entero determinístico a partir del id (String)
/// de cada bloque/recordatorio usando su hashCode.
class NotificationService {
  NotificationService._();
  static final NotificationService instancia = NotificationService._();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _inicializado = false;

  Future<void> inicializar() async {
    if (_inicializado) return;

    tz_data.initializeTimeZones();
    // TODO: si quieres detectar la zona horaria real del dispositivo en vez
    // de asumir America/Caracas, se puede integrar el paquete
    // flutter_timezone más adelante. Por ahora la fijamos porque la app
    // es de uso local en Venezuela.
    tz.setLocalLocation(tz.getLocation('America/Caracas'));

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);

    _inicializado = true;
  }

  int _idDesde(String id) => id.hashCode & 0x7fffffff; // siempre positivo

  /// Programa (o reemplaza) la notificación recurrente semanal de un
  /// bloque de horario, `minutosAntes` antes de que inicie la clase.
  Future<void> programarBloque(BloqueHorario bloque, Materia materia) async {
    if (!bloque.notificarInicio) {
      await cancelarBloque(bloque.id);
      return;
    }
    await inicializar();

    final minutosNotificacion = bloque.horaInicio - bloque.minutosAntes;
    final hora = minutosNotificacion ~/ 60;
    final minuto = minutosNotificacion % 60;

    final proxima = _proximaOcurrencia(bloque.diaSemana, hora, minuto);

    await _plugin.zonedSchedule(
      _idDesde(bloque.id),
      '${materia.nombre} empieza en ${bloque.minutosAntes} min',
      materia.aula != null ? 'Aula ${materia.aula}' : 'Prepárate para grabar',
      proxima,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'horario_channel',
          'Horario de clases',
          channelDescription: 'Avisos antes de que empiece cada clase',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelarBloque(String bloqueId) async {
    await inicializar();
    await _plugin.cancel(_idDesde(bloqueId));
  }

  /// Programa una notificación puntual (no recurrente) para un recordatorio
  /// — prueba, entrega, fecha importante. Si la fecha ya pasó, no programa.
  Future<void> programarRecordatorio(Recordatorio r) async {
    await inicializar();
    final fecha = tz.TZDateTime.from(r.fechaHora, tz.local);
    if (fecha.isBefore(tz.TZDateTime.now(tz.local))) return;

    final etiquetaTipo = switch (r.tipo) {
      'prueba' => 'Prueba',
      'entrega' => 'Entrega',
      _ => 'Recordatorio',
    };

    await _plugin.zonedSchedule(
      _idDesde(r.id),
      '$etiquetaTipo: ${r.titulo}',
      r.notas ?? '',
      fecha,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'recordatorios_channel',
          'Pruebas y entregas',
          channelDescription: 'Avisos de fechas importantes',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelarRecordatorio(String recordatorioId) async {
    await inicializar();
    await _plugin.cancel(_idDesde(recordatorioId));
  }

  /// Calcula la próxima fecha/hora (a partir de ahora) en que cae un día de
  /// la semana + hora específica. `diaSemana` usa el estándar de DateTime
  /// (1 = lunes ... 7 = domingo), igual que `BloqueHorario`.
  tz.TZDateTime _proximaOcurrencia(int diaSemana, int hora, int minuto) {
    var fecha = tz.TZDateTime.now(tz.local);
    fecha = tz.TZDateTime(
        tz.local, fecha.year, fecha.month, fecha.day, hora, minuto);
    while (fecha.weekday != diaSemana || fecha.isBefore(tz.TZDateTime.now(tz.local))) {
      fecha = fecha.add(const Duration(days: 1));
    }
    return fecha;
  }
}
