import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';

enum ProveedorTranscripcion { openai, groq }

/// Transcribe audio usando OpenAI Whisper o Groq Whisper.
/// Ambos usan el mismo modelo (whisper-large-v3), la misma calidad,
/// y la misma interfaz de API — solo cambia la URL y la clave.
///
/// Groq es completamente gratuito (7.200 segundos/día) y solo
/// requiere crear una cuenta en console.groq.com con email.
class TranscriptionService {
  TranscriptionService._();
  static final TranscriptionService instancia = TranscriptionService._();

  static const _urlOpenAI = 'https://api.openai.com/v1/audio/transcriptions';
  static const _urlGroq   = 'https://api.groq.com/openai/v1/audio/transcriptions';

  String? _apiKey;
  ProveedorTranscripcion _proveedor = ProveedorTranscripcion.groq;

  void configurar({
    required String apiKey,
    ProveedorTranscripcion proveedor = ProveedorTranscripcion.groq,
  }) {
    _apiKey = apiKey;
    _proveedor = proveedor;
  }

  bool get estaConfigurado => _apiKey != null && _apiKey!.isNotEmpty;
  ProveedorTranscripcion get proveedor => _proveedor;

  Future<String> transcribir(String ruta) async {
    if (!estaConfigurado) {
      throw TranscriptionException(
          'API key no configurada. Ve a Ajustes para agregarla.');
    }

    final archivo = File(ruta);
    if (!await archivo.exists()) {
      throw TranscriptionException('Archivo de audio no encontrado: $ruta');
    }

    final url = _proveedor == ProveedorTranscripcion.groq
        ? _urlGroq
        : _urlOpenAI;

    // Groq Whisper usa el mismo modelo que OpenAI pero con su nombre propio.
    // OpenAI usa 'whisper-1', Groq usa 'whisper-large-v3-turbo' (más rápido)
    // o 'whisper-large-v3' (más preciso).
    final modelo = _proveedor == ProveedorTranscripcion.groq
        ? 'whisper-large-v3-turbo'
        : 'whisper-1';

    final request = http.MultipartRequest('POST', Uri.parse(url));
    request.headers['Authorization'] = 'Bearer $_apiKey';
    request.fields['model'] = modelo;
    request.fields['language'] = 'es';
    request.fields['response_format'] = 'verbose_json';
    request.files.add(await http.MultipartFile.fromPath('file', ruta));

    final streamed = await request.send();
    final respuesta = await http.Response.fromStream(streamed);

    if (respuesta.statusCode != 200) {
      final error = jsonDecode(respuesta.body);
      throw TranscriptionException(
          'Error de transcripción (${respuesta.statusCode}): '
          '${error['error']?['message'] ?? respuesta.body}');
    }

    final json = jsonDecode(respuesta.body);
    if (json['segments'] != null) {
      return (json['segments'] as List)
          .map((s) => s['text'] as String)
          .join(' ')
          .trim();
    }
    return json['text'] as String? ?? '';
  }
}

class TranscriptionException implements Exception {
  final String mensaje;
  const TranscriptionException(this.mensaje);

  @override
  String toString() => 'TranscriptionException: $mensaje';
}
