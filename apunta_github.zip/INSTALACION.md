# Apunta — Guía de instalación

Esta guía te lleva desde cero hasta tener la app corriendo en tu Android,
sin necesidad de publicar en Play Store.

---

## Lo que necesitas en tu computadora

| Herramienta | Por qué | Dónde bajarla |
|---|---|---|
| Flutter SDK | El framework de la app | https://docs.flutter.dev/get-started/install |
| Android Studio | Para compilar el APK y manejar el SDK de Android | https://developer.android.com/studio |
| VS Code (opcional) | Editor más liviano que Android Studio | https://code.visualstudio.com |
| Git (opcional) | Para versionar el proyecto | https://git-scm.com |

**Sistema operativo**: Windows, macOS o Linux funcionan igual.

---

## Paso 1 — Instalar Flutter

### Windows
1. Descarga el ZIP de Flutter desde https://docs.flutter.dev/get-started/install/windows
2. Extráelo en `C:\flutter` (evita rutas con espacios o caracteres especiales)
3. Agrega `C:\flutter\bin` al PATH del sistema:
   - Busca "Variables de entorno" en el menú Inicio
   - Edita la variable `Path` del usuario
   - Agrega `C:\flutter\bin`

### macOS
```bash
# Con Homebrew (recomendado)
brew install flutter

# O manualmente: descarga el ZIP, extrae en ~/flutter
# y agrega esta línea a tu ~/.zshrc o ~/.bash_profile:
export PATH="$HOME/flutter/bin:$PATH"
```

### Linux
```bash
sudo snap install flutter --classic
```

### Verificar la instalación
```bash
flutter doctor
```
Este comando te dice exactamente qué falta. La meta es que todos los
elementos relevantes (Flutter, Android toolchain) estén en verde ✓.

---

## Paso 2 — Instalar Android Studio

1. Descarga desde https://developer.android.com/studio e instala.
2. En la primera ejecución acepta el asistente de configuración — instalará
   el Android SDK automáticamente.
3. Acepta las licencias de Android:
   ```bash
   flutter doctor --android-licenses
   # Presiona 'y' para aceptar cada licencia
   ```

No necesitas crear un emulador — vamos a correr la app directo en tu
teléfono físico, que es mucho más rápido y más real.

---

## Paso 3 — Preparar tu teléfono Android

### Activar Opciones de desarrollador
1. Ve a **Ajustes → Acerca del teléfono**
2. Toca **Número de compilación** 7 veces seguidas
3. Aparece el mensaje "¡Ya eres desarrollador!"

### Activar Depuración USB
1. Ve a **Ajustes → Opciones de desarrollador** (o Sistema → Opciones de desarrollador)
2. Activa **Depuración USB**

### Conectar por USB
Conecta el teléfono al computador. En el teléfono aparecerá un diálogo
preguntando si confías en el computador — toca **Permitir**.

Verifica que Flutter lo detecta:
```bash
flutter devices
```
Debe aparecer tu teléfono en la lista.

---

## Paso 4 — Preparar el proyecto

```bash
# 1. Descomprime el ZIP del proyecto
# Tendrás una carpeta llamada class_tracker_app

# 2. Entra a la carpeta
cd class_tracker_app

# 3. Descarga todas las dependencias de Flutter
flutter pub get

# 4. Genera el ícono de la app en todos los tamaños de Android
dart run flutter_launcher_icons

# 5. Verifica que todo esté bien
flutter doctor
```

---

## Paso 5 — Instalar la app en tu teléfono

```bash
# Con el teléfono conectado por USB:
flutter run
```

La primera compilación tarda 3-5 minutos (descarga librerías de Android).
Las siguientes son mucho más rápidas.

Verás algo como:
```
Launching lib/main.dart on Samsung Galaxy S23...
✓ Built build/app/outputs/flutter-apk/app-debug.apk
Installing build/app/outputs/flutter-apk/app-debug.apk...
```

La app se instala y abre sola en tu teléfono. 🎉

---

## Paso 6 — Generar el APK para distribuir sin cable

Si quieres instalar la app en el teléfono de tus hijos sin conectarla a la
computadora cada vez, genera un APK y envíasela por WhatsApp o Drive:

```bash
flutter build apk --release
```

El archivo queda en:
```
build/app/outputs/flutter-apk/app-release.apk
```

**Para instalar el APK en otro teléfono:**
1. Envía el archivo `.apk` por WhatsApp, Telegram, Drive o email
2. En el teléfono receptor, abre el archivo
3. Android pedirá permiso para instalar apps de fuentes desconocidas —
   actívalo solo para esa instalación (Ajustes → Seguridad → Instalar
   apps desconocidas)
4. La app se instala como cualquier app normal

> ⚠️ La versión `--release` es más rápida y no requiere que el teléfono
> esté conectado a la computadora. La versión `--debug` (la que produce
> `flutter run`) es más lenta pero muestra errores en tiempo real.

---

## Configuración específica por fabricante (importante)

Algunos fabricantes tienen restricciones extra que pueden afectar la
grabación en segundo plano. Sigue estos pasos según el teléfono:

### Samsung (One UI)
- Ajustes → Batería → Optimización de batería
- Busca "Apunta" → selecciona **Sin restricciones**
- También: Ajustes → Apps → Apunta → Batería → **Sin restricciones**

### Xiaomi / Redmi (MIUI)
- Ajustes → Apps → Administrar apps → Apunta → Ahorro de energía → **Sin restricciones**
- Ajustes → Apps → Administrar apps → Apunta → **Inicio automático: activar**
- Panel de notificaciones → mantén presionada la notificación de grabación
  → Activar para que no se silencie

### Huawei / Honor (EMUI)
- Ajustes → Apps → Apunta → Batería → **Lanzamiento de la aplicación**
- Desactiva "Gestionar automáticamente" y activa manualmente los tres
  interruptores (Inicio automático, Inicio secundario, Ejecutar en
  segundo plano)

### Motorola / Google Pixel / OnePlus
- Generalmente no requieren configuración extra. El servicio de grabación
  funciona con solo darle permiso de micrófono.

---

## Permisos que pedirá la app

| Permiso | Por qué es necesario |
|---|---|
| Micrófono | Para grabar las clases |
| Notificaciones | Para los avisos del horario y recordatorios |
| Cámara | Para fotografiar el pizarrón |
| Galería / fotos | Para agregar fotos desde la galería |
| Alarmas exactas | Para que las notificaciones del horario lleguen en el horario preciso |

Todos se pueden revocar desde Ajustes → Apps → Apunta → Permisos.

---

## Solución de problemas comunes

**`flutter doctor` muestra "Android SDK not found"**
→ Abre Android Studio, ve a SDK Manager y verifica que el SDK de Android
  esté instalado. Luego corre `flutter doctor` de nuevo.

**El teléfono no aparece en `flutter devices`**
→ Verifica que la Depuración USB esté activa y que aceptaste el diálogo de
  confianza en el teléfono. Prueba desconectando y reconectando el cable.

**Error de compilación: "SDK version too old"**
→ En Android Studio, abre SDK Manager y actualiza el Build Tools.

**La grabación se detiene cuando se apaga la pantalla**
→ El fabricante está matando el proceso. Sigue las instrucciones de la
  sección "Configuración específica por fabricante" de arriba.

**La app se instala pero no abre**
→ Corre `flutter logs` con el teléfono conectado para ver el error exacto.

---

## Actualizaciones futuras

Cuando haya una versión nueva del código:
```bash
cd class_tracker_app
flutter pub get          # actualizar dependencias si cambiaron
flutter build apk --release  # generar nuevo APK
```

Envía el nuevo APK por WhatsApp a los teléfonos de tus hijos — Android
preguntará si quieres actualizar la app existente.

---

*Proyecto iniciado el Día del Padre, 22 de junio de 2026.*
*Hecho con 🙏🏾 para el futuro de tus hijos.*
